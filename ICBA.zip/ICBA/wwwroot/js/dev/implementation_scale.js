﻿$(document).ready(() => Attach_ImplementationScale_Events());

const Attach_ImplementationScale_Events = () => {
    const API_URL = "ImplementationScale?handler=ImplementationScaleData";

    const C = {
        navy: "#002677",
        orange: "#e38a6e",
        navy2: "#2f52a0",
        gold: "#f0a202",
        green: "#157a4a",
        grey: "#c7ccd6",
        red: "#b4231a",
        slate: "#6f7bbf"
    };

    let ixFunnelChart = null;
    let ixStageChart = null;
    let ixConvChart = null;
    let ixAirbChart = null;
    let loadTimer = null;

    const ToNumber = (v) => Number.isNaN(Number(v)) ? 0 : Number(v);
    const FormatN = (n) => ToNumber(n).toLocaleString("en-US");
    const FormatPct = (n) => `${(ToNumber(n) * 100).toFixed(1)}%`;
    const FormatMoney = (n) => {
        const v = ToNumber(n);
        const a = Math.abs(v);
        const sign = v < 0 ? "-" : "";
        if (a >= 1e9) return `${sign}$${(a / 1e9).toFixed(2)}Bn`;
        if (a >= 1e6) return `${sign}$${(a / 1e6).toFixed(2)}Mn`;
        if (a >= 1e3) return `${sign}$${(a / 1e3).toFixed(0)}K`;
        return `${sign}$${Math.round(a).toLocaleString("en-US")}`;
    };

    const DestroyChart = (c) => { if (c) c.destroy(); };

    const SetScopeCount = (count) => {
        if (window.CommonFilters && typeof window.CommonFilters.setScopeCount === "function") {
            window.CommonFilters.setScopeCount(ToNumber(count));
        }
    };

    const GetPayload = (filters) => ({
        capability: filters?.capability || "",
        business: filters?.business || "",
        geo: filters?.geo || "",
        priority: filters?.priority || "",
        stage: filters?.stage || "",
        timeType: filters?.timeType || "all",
        year: filters?.year || "",
        start: filters?.start || "",
        end: filters?.end || ""
    });

    const BuildEffectiveFilters = (filters) => {
        const globalFilters = window.CommonFilters && typeof window.CommonFilters.getValues === "function"
            ? window.CommonFilters.getValues()
            : {};

        const directWeights = {
            inApproval: filters?.inApproval,
            approvedNoOwner: filters?.approvedNoOwner,
            approvedWithPlan: filters?.approvedWithPlan,
            inImplementation: filters?.inImplementation,
            implementedNotValidated: filters?.implementedNotValidated,
            validated: filters?.validated
        };

        return {
            ...globalFilters,
            ...(filters || {}),
            ...Object.fromEntries(Object.entries(directWeights).filter(([, v]) => v !== undefined && v !== null))
        };
    };

    const RenderKpis = (kpis) => {
        const implemented = ToNumber(kpis?.implemented);
        const valid = ToNumber(kpis?.valid);
        const scaled = ToNumber(kpis?.scaled);

        $("#ixSubmitToImplement").text(FormatPct(kpis?.submitToImplementRate ?? 0));
        $("#ixApproveToImplement").text(FormatPct(kpis?.approveToImplementRate ?? 0));
        $("#ixNotImplemented").text(FormatN(kpis?.notImplemented ?? 0));
        $("#ixScaled").text(FormatN(scaled));

        $("#ixImplementedCount").text(FormatN(implemented));
        $("#ixValidCount").text(FormatN(valid));
        $("#ixScaledPct").text(implemented > 0 ? FormatPct(scaled / implemented) : "0.0%");

        $("#ixCbaImplemented").text(FormatMoney(kpis?.cbaImplemented ?? 0));
        $("#ixCbaApprovedNotImpl").text(FormatMoney(kpis?.cbaApprovedNotImpl ?? 0));
    };

    const RenderAirbKpis = (airb) => {
        $("#ixAirbNeed").text(FormatN(airb?.need ?? 0));
        $("#ixAirbApproved").text(FormatN(airb?.approved ?? 0));
        $("#ixAirbNotSubmitted").text(FormatN(airb?.notSubmitted ?? 0));
        $("#ixAirbNoApproval").text(FormatN(airb?.implementedNoAirb ?? 0));
    };

    const RenderAirbGateNote = (airb) => {
        const need = ToNumber(airb?.need);
        const approved = ToNumber(airb?.approved);
        const notSubmitted = ToNumber(airb?.notSubmitted);
        const implementedNoAirb = ToNumber(airb?.implementedNoAirb);

        const $note = $("#ixAirbGateNote");
        const $text = $("#ixAirbGateText");
        if (!$note.length || !$text.length) return;

        $note.removeClass("info");

        if (need > 0) {
            const suffix = implementedNoAirb > 0
                ? `, and ${FormatN(implementedNoAirb)} already implemented without AIRB approval (review required).`
                : ".";
            $text.html(
                `<b>AIRB gate:</b> AI Review Board approval is mandatory before any AI idea moves to production. ` +
                `${FormatN(need)} AI projects are in scope — ${FormatN(approved)} approved, ` +
                `${FormatN(notSubmitted)} not yet submitted${suffix}`
            );
        } else {
            $note.addClass("info");
            $text.html(`<b>AIRB gate:</b> AI Review Board approval is mandatory before any AI idea moves to production. No AI projects in the current filter, so the AIRB gate does not apply.`);
        }
    };

    const RenderFunnelChart = (items) => {
        const canvas = document.getElementById("ixFunnel");
        if (!canvas) return;
        DestroyChart(ixFunnelChart);

        const labels = (items || []).map(x => x.name);
        const values = (items || []).map(x => ToNumber(x.count));

        ixFunnelChart = new Chart(canvas, {
            type: "bar",
            data: {
                labels,
                datasets: [{
                    label: "Count",
                    data: values,
                    backgroundColor: C.navy,
                    borderRadius: 6,
                    maxBarThickness: 26
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: "y",
                plugins: { legend: { display: false } },
                scales: {
                    x: { beginAtZero: true, grid: { color: "#eef0f4" } },
                    y: { grid: { display: false } }
                }
            }
        });
    };

    const RenderStageChart = (items) => {
        const canvas = document.getElementById("ixStage");
        if (!canvas) return;
        DestroyChart(ixStageChart);

        const labels = (items || []).map(x => x.name);
        const values = (items || []).map(x => ToNumber(x.count));

        ixStageChart = new Chart(canvas, {
            type: "bar",
            data: {
                labels,
                datasets: [{
                    data: values,
                    backgroundColor: [C.navy2, C.gold, C.green],
                    borderRadius: 5,
                    maxBarThickness: 60
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    x: { grid: { display: false } },
                    y: { beginAtZero: true }
                }
            }
        });
    };

    const RenderConvChart = (items) => {
        const canvas = document.getElementById("ixConv");
        if (!canvas) return;
        DestroyChart(ixConvChart);

        const labels = (items || []).map(x => x.capability);
        const approval = (items || []).map(x => ToNumber(x.approvalRate));
        const implementation = (items || []).map(x => ToNumber(x.implementationRate));

        ixConvChart = new Chart(canvas, {
            type: "bar",
            data: {
                labels,
                datasets: [
                    { label: "Approval %", data: approval, backgroundColor: C.navy, borderRadius: 4, maxBarThickness: 18 },
                    { label: "Implementation %", data: implementation, backgroundColor: C.orange, borderRadius: 4, maxBarThickness: 18 }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: "bottom" } },
                scales: {
                    x: { grid: { display: false }, ticks: { autoSkip: false, maxRotation: 35, minRotation: 0 } },
                    y: { beginAtZero: true, ticks: { callback: (v) => `${v}%` } }
                }
            }
        });
    };

    const RenderAirbChart = (items) => {
        const canvas = document.getElementById("ixAirb");
        if (!canvas) return;
        DestroyChart(ixAirbChart);

        const labels = (items || []).map(x => x.name);
        const values = (items || []).map(x => ToNumber(x.count));

        const colorMap = {
            "Approved": C.green,
            "In review": C.gold,
            "Not submitted": C.orange,
            "Rejected": C.red,
            "Not applicable": C.grey,
            "Other": C.slate
        };

        ixAirbChart = new Chart(canvas, {
            type: "doughnut",
            data: {
                labels,
                datasets: [{ data: values, backgroundColor: labels.map(l => colorMap[l] ?? C.grey), borderWidth: 0 }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: "60%",
                plugins: { legend: { position: "bottom" } }
            }
        });
    };

    const RenderFunnelSteps = (items) => {
        const $host = $("#ixFunnelSteps");
        if (!$host.length) return;

        const safeItems = Array.isArray(items) ? items : [];
        if (!safeItems.length) {
            $host.html(`<div class="muted">No data available</div>`);
            return;
        }

        let html = "";
        safeItems.forEach(x => {
            const n = ToNumber(x.count);
            const base = ToNumber(x.baseCount);
            const pct = base > 0 ? (n / base) : 0;

            html += `
            <div class="step">
                <span class="name">${x.name}</span>
                <div class="bar-track">
                    <div class="bar-fill" style="width:${Math.max(pct * 100, 1.5)}%"></div>
                </div>
                <span class="val">${FormatN(n)} <small>${(pct * 100).toFixed(1)}%</small></span>
            </div>
        `;
        });

        $host.html(html);
    };

    const LoadImplementationScale = (filters) => {
        const effectiveFilters = BuildEffectiveFilters(filters);

        $.ajax({
            url: API_URL,
            type: "GET",
            cache: false,
            data: GetPayload(effectiveFilters),
            success: (response) => {
                SetScopeCount(response?.totalRecords ?? 0);
                RenderKpis(response?.kpis ?? {});
                RenderAirbKpis(response?.airbKpis ?? {});
                RenderAirbGateNote(response?.airbKpis ?? {});
                RenderFunnelChart(response?.stagePipeline ?? []);
                RenderFunnelSteps(response?.funnelSteps ?? []);
                RenderStageChart(response?.stagePipeline ?? []);
                RenderConvChart(response?.conversionByCapability ?? []);
                RenderAirbChart(response?.airbStatus ?? []);
            },
            error: (xhr) => {
                console.error("Failed to load Implementation Scale data", xhr);
                SetScopeCount(0);
                RenderKpis({});
                RenderAirbKpis({});
                RenderAirbGateNote({});
                RenderFunnelChart([]);
                RenderFunnelSteps([]);
                RenderStageChart([]);
                RenderConvChart([]);
                RenderAirbChart([]);
            }
        });
    };

    const Attach_Filter_Events = () => {
        $(document)
            .off("commonFilterChanged.implementation")
            .on("commonFilterChanged.implementation", (_e, filters) => {
                if (loadTimer) clearTimeout(loadTimer);
                loadTimer = setTimeout(() => {
                    LoadImplementationScale(filters || {});
                }, 250);
            });

        $(document)
            .off("forecastConfigApplied.implementation")
            .on("forecastConfigApplied.implementation", (_e, weights) => {
                const base = window.CommonFilters ? window.CommonFilters.getValues() : {};
                LoadImplementationScale({ ...base, ...(weights || {}) });
            });
    };

    const Init_ImplementationScale = () => {
        if (!window.CommonFilters && typeof Attach_Common_Events === "function") {
            Attach_Common_Events();
        } else if (!window.CommonFilters && typeof attach_common_events === "function") {
            attach_common_events();
        }

        const filters = window.CommonFilters ? window.CommonFilters.getValues() : {};
        LoadImplementationScale(filters);
        Attach_Filter_Events();
    };

    Init_ImplementationScale();
};