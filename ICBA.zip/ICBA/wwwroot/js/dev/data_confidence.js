﻿$(document).ready(() => Attach_DataConfidence_Events());

const Attach_DataConfidence_Events = () => {
    const API_URL = "DataConfidence?handler=DataConfidenceData";
    let loadTimer = null;

    const ToNumber = (v) => Number.isNaN(Number(v)) ? 0 : Number(v);
    const FormatN = (n) => ToNumber(n).toLocaleString("en-US");
    const FormatPct = (n) => `${(ToNumber(n) * 100).toFixed(1)}%`;

    const Get = (obj, camel, pascal) => obj?.[camel] ?? obj?.[pascal];

    const SetScopeCount = (count) => {
        if (window.CommonFilters && typeof window.CommonFilters.setScopeCount === "function") {
            window.CommonFilters.setScopeCount(ToNumber(count));
        }
    };

    const GetPayload = (filters) => ({
        capability: filters?.capability || "",
        business: filters?.business || "",
        geo: filters?.geo || "",
        priority: filters?.priority || "",
        stage: filters?.stage || "",
        timeType: filters?.timeType || "all",
        year: filters?.year || "",
        start: filters?.start || "",
        end: filters?.end || ""
    });

    const BuildEffectiveFilters = (filters) => {
        const globalFilters = window.CommonFilters && typeof window.CommonFilters.getValues === "function"
            ? window.CommonFilters.getValues()
            : {};

        const directWeights = {
            inApproval: filters?.inApproval,
            approvedNoOwner: filters?.approvedNoOwner,
            approvedWithPlan: filters?.approvedWithPlan,
            inImplementation: filters?.inImplementation,
            implementedNotValidated: filters?.implementedNotValidated,
            validated: filters?.validated
        };

        return {
            ...globalFilters,
            ...(filters || {}),
            ...Object.fromEntries(Object.entries(directWeights).filter(([, v]) => v !== undefined && v !== null))
        };
    };

    const StatusClass = (rate) => {
        const r = ToNumber(rate);
        if (r === 0) return "b-green";
        if (r < 0.10) return "b-amber";
        return "b-red";
    };

    const StatusText = (rate) => {
        const r = ToNumber(rate);
        if (r === 0) return "Clean";
        if (r < 0.10) return "Minor gaps";
        return "Review";
    };

    const ReadinessBadgeClass = (status) => {
        if (status === "Reliable") return "b-green";
        if (status === "Proxy") return "b-amber";
        if (status === "Needs field") return "b-info";
        return "b-grey";
    };

    const NormalizeChecks = (checks) => {
        if (!Array.isArray(checks)) return [];
        return checks.map(x => ({
            name: x?.name ?? x?.Name ?? "-",
            count: ToNumber(x?.count ?? x?.Count),
            rate: ToNumber(x?.rate ?? x?.Rate)
        }));
    };

    const NormalizeReadiness = (items) => {
        if (!Array.isArray(items)) return [];
        return items.map(x => ({
            name: x?.name ?? x?.Name ?? "-",
            desc: x?.desc ?? x?.Desc ?? "-",
            status: x?.status ?? x?.Status ?? "-"
        }));
    };

    const RenderChecks = (checks) => {
        const rows = NormalizeChecks(checks);
        const $body = $("#dcChecksBody");
        if (!$body.length) return;

        if (!rows.length) {
            $body.html(`<tr><td colspan="4" class="muted">No data available</td></tr>`);
            return;
        }

        const html = rows.map(r => `
            <tr>
                <td class="strong">${r.name}</td>
                <td class="num">${FormatN(r.count)}</td>
                <td>${FormatPct(r.rate)}</td>
                <td><span class="badge ${StatusClass(r.rate)}">${StatusText(r.rate)}</span></td>
            </tr>
        `).join("");

        $body.html(html);
    };

    const RenderReadiness = (items) => {
        const rows = NormalizeReadiness(items);
        const $host = $("#dcReadiness");
        if (!$host.length) return;

        if (!rows.length) {
            $host.html(`<div class="muted">No readiness data available</div>`);
            return;
        }

        const html = rows.map(r => `
            <div class="r-row">
                <span class="r-name">${r.name}</span>
                <span class="r-desc">${r.desc}</span>
                <span class="badge ${ReadinessBadgeClass(r.status)}">${r.status}</span>
            </div>
        `).join("");

        $host.html(html);
    };

    const LoadDataConfidence = (filters) => {
        const effectiveFilters = BuildEffectiveFilters(filters);

        $.ajax({
            url: API_URL,
            type: "GET",
            cache: false,
            data: GetPayload(effectiveFilters),
            success: (response) => {
                SetScopeCount(Get(response, "totalRecords", "TotalRecords") ?? 0);

                const checks = Get(response, "checks", "Checks") ?? [];
                const readiness = Get(response, "readiness", "Readiness") ?? [];

                RenderChecks(checks);
                RenderReadiness(readiness);
            },
            error: (xhr) => {
                console.error("Failed to load Data Confidence data", xhr);
                SetScopeCount(0);
                RenderChecks([]);
                RenderReadiness([]);
            }
        });
    };

    const Attach_Filter_Events = () => {
        $(document)
            .off("commonFilterChanged.dataConfidence")
            .on("commonFilterChanged.dataConfidence", (_e, filters) => {
                if (loadTimer) clearTimeout(loadTimer);
                loadTimer = setTimeout(() => {
                    LoadDataConfidence(filters || {});
                }, 250);
            });

        $(document)
            .off("forecastConfigApplied.dataConfidence")
            .on("forecastConfigApplied.dataConfidence", (_e, weights) => {
                const base = window.CommonFilters ? window.CommonFilters.getValues() : {};
                LoadDataConfidence({ ...base, ...(weights || {}) });
            });
    };

    const Init_DataConfidence = () => {
        if (!window.CommonFilters && typeof Attach_Common_Events === "function") {
            Attach_Common_Events();
        } else if (!window.CommonFilters && typeof attach_common_events === "function") {
            attach_common_events();
        }

        const filters = window.CommonFilters ? window.CommonFilters.getValues() : {};
        LoadDataConfidence(filters);
        Attach_Filter_Events();
    };

    Init_DataConfidence();
};