﻿$(document).ready(() => Attach_Leadership_Events());

const Attach_Leadership_Events = () => {

    const API_URL = "Index?handler=LeadershipCockpitData";

    const C = {
        orange: "#e38a6e",
        navy: "#002677",
        navy2: "#2f52a0",
        teal: "#0f9d94",
        gold: "#f0a202",
        slate: "#6f7bbf",
        grey: "#c7ccd6",
        green: "#157a4a",
        amber: "#a86300",
        red: "#b4231a"
    };

    const SERIES = [C.navy, C.orange, C.teal, C.gold, C.slate, C.green, C.red, C.grey];
    const STAGE_ORDER = ["Draft", "In Approval", "Approved", "In Implementation", "Implemented", "Rejected", "Others"];
    const MONTH_LABELS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    const GetMonthIndex = (name) => {
        const key = (name || "").toString().trim().toUpperCase().slice(0, 3);
        return MONTH_LABELS.indexOf(key);
    };

    let aiSplitChart = null;
    let cbaChart = null;
    let trendChart = null;
    let mixChart = null;
    let rejectChart = null;
    let rejectByChart = null;

    const ToNumber = (value) => {
        const n = Number(value);
        return Number.isNaN(n) ? 0 : n;
    };

    const FormatN = (n) => ToNumber(n).toLocaleString("en-US");
    const FormatPct = (n) => `${(ToNumber(n) * 100).toFixed(1)}%`;
    const FormatCompact = (n) => {
        const v = ToNumber(n);
        const a = Math.abs(v);
        if (a >= 1_000_000_000) return `${(v / 1_000_000_000).toFixed(1)}B`;
        if (a >= 1_000_000) return `${(v / 1_000_000).toFixed(1)}M`;
        if (a >= 1_000) return `${(v / 1_000).toFixed(1)}K`;
        return Math.round(v).toLocaleString("en-US");
    };

    const GetPayload = (filters) => ({
        capability: filters?.capability || "",
        business: filters?.business || "",
        geo: filters?.geo || "",
        priority: filters?.priority || "",
        stage: filters?.stage || "",
        timeType: filters?.timeType || "all",
        year: filters?.year || "",
        start: filters?.start || "",
        end: filters?.end || "",

        inApproval: filters?.inApproval ?? 10,
        approvedNoOwner: filters?.approvedNoOwner ?? 25,
        approvedWithPlan: filters?.approvedWithPlan ?? 50,
        inImplementation: filters?.inImplementation ?? 75,
        implementedNotValidated: filters?.implementedNotValidated ?? 90,
        validated: filters?.validated ?? 100
    });

    const NormalizeItems = (items) => {
        if (!Array.isArray(items)) return [];
        return items
            .map(x => ({
                name: (x?.name ?? x?.Name ?? x?.label ?? x?.Label ?? "").toString().trim(),
                count: ToNumber(x?.count ?? x?.Count ?? x?.value ?? x?.Value ?? 0),
                rate: x?.rate ?? x?.Rate ?? x?.approvalRate ?? x?.ApprovalRate ?? null,
                approvalRate: x?.approvalRate ?? x?.ApprovalRate ?? x?.rate ?? x?.Rate ?? null
            }))
            .filter(x => x.name.length > 0);
    };

    const SortByCountDesc = (items) =>
        [...items].sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));

    const SortStageItems = (items) =>
        [...items].sort((a, b) => {
            const ai = STAGE_ORDER.indexOf(a.name);
            const bi = STAGE_ORDER.indexOf(b.name);
            const av = ai === -1 ? Number.MAX_SAFE_INTEGER : ai;
            const bv = bi === -1 ? Number.MAX_SAFE_INTEGER : bi;
            if (av !== bv) return av - bv;
            return b.count - a.count || a.name.localeCompare(b.name);
        });

    const GetStageCount = (stageItems, stageName) => {
        const hit = stageItems.find(x => x.name.toLowerCase() === stageName.toLowerCase());
        return hit ? hit.count : 0;
    };

    const SetScopeCount = (count) => {
        if (window.CommonFilters && typeof window.CommonFilters.setScopeCount === "function") {
            window.CommonFilters.setScopeCount(ToNumber(count));
        }
    };

    const DestroyChart = (chartRef) => {
        if (chartRef) chartRef.destroy();
    };


    const GetBarOptions = (showLegend = false, horizontal = false) => ({
        responsive: true,
        maintainAspectRatio: false,
        indexAxis: horizontal ? "y" : "x",
        plugins: {
            legend: { display: showLegend, position: "bottom" },
            tooltip: { mode: "index", intersect: false }
        },
        scales: horizontal
            ? {
                x: {
                    beginAtZero: true,
                    ticks: { precision: 0 },
                    grid: { color: "#eef0f4" }
                },
                y: {
                    ticks: { autoSkip: false },
                    grid: { display: false }
                }
            }
            : {
                x: {
                    ticks: { autoSkip: false, maxRotation: 35, minRotation: 0 },
                    grid: { display: false }
                },
                y: {
                    beginAtZero: true,
                    ticks: { precision: 0 },
                    grid: { color: "#eef0f4" }
                }
            }
    });

    const UpsertBarChart = (chartRef, canvasId, label, items, color, horizontal = false) => {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return chartRef;

        DestroyChart(chartRef);

        const safeItems = Array.isArray(items) ? items : [];
        const labels = safeItems.length ? safeItems.map(x => x.name) : ["No data"];
        const values = safeItems.length ? safeItems.map(x => x.count) : [0];

        return new Chart(canvas, {
            type: "bar",
            data: {
                labels,
                datasets: [{
                    label,
                    data: values,
                    backgroundColor: color,
                    borderRadius: 6,
                    maxBarThickness: 36
                }]
            },
            options: GetBarOptions(false, horizontal)
        });
    };

    const RenderRejectChart = (priorityItems) => {
        rejectChart = UpsertBarChart(
            rejectChart,
            "cxReject",
            "Rejection reasons",
            SortByCountDesc(priorityItems).slice(0, 8),
            C.red,
            true
        );
    };

    const DoughnutPercentPlugin = {
        id: "doughnutPercentLabels",
        afterDatasetsDraw: (chart, _args, pluginOptions) => {
            const dataset = chart?.data?.datasets?.[0];
            if (!dataset) return;

            const raw = (dataset.data || []).map(ToNumber);
            const visibleData = raw.map((v, i) => (chart.getDataVisibility(i) ? v : 0));
            const total = visibleData.reduce((sum, v) => sum + v, 0);
            if (!total) return;

            const meta = chart.getDatasetMeta(0);
            const { ctx } = chart;

            ctx.save();
            ctx.fillStyle = pluginOptions?.color || "#ffffff";
            ctx.font = pluginOptions?.font || "600 11px Segoe UI";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";

            meta.data.forEach((arc, i) => {
                if (!chart.getDataVisibility(i)) return; // hidden slice
                const val = visibleData[i];
                if (val <= 0) return;

                const pct = (val / total) * 100;
                if (pct < 4) return;

                const { x, y } = arc.tooltipPosition();
                ctx.fillText(`${pct.toFixed(1)}%`, x, y);
            });

            ctx.restore();
        }
    };

    const GetDoughnutOptions = () => ({
        responsive: true,
        maintainAspectRatio: false,
        cutout: "62%",
        plugins: {
            legend: {
                display: true,
                position: "bottom",
                labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true }
            },
            tooltip: {
                callbacks: {
                    label: (ctx) => {
                        const val = ToNumber(ctx.raw);
                        const total = (ctx.dataset.data || []).reduce((s, v, i) => {
                            return s + (ctx.chart.getDataVisibility(i) ? ToNumber(v) : 0);
                        }, 0);

                        const pct = total ? ((val / total) * 100).toFixed(1) : "0.0";
                        return `${ctx.label}: ${val.toLocaleString("en-US")} (${pct}%)`;
                    }
                }
            },
            doughnutPercentLabels: {
                color: "#ffffff",
                font: "600 11px Segoe UI"
            }
        }
    });

    const UpsertDoughnutChart = (chartRef, canvasId, label, items) => {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return chartRef;

        DestroyChart(chartRef);

        const safeItems = Array.isArray(items) ? items : [];
        const labels = safeItems.length ? safeItems.map(x => x.name) : ["No data"];
        const values = safeItems.length ? safeItems.map(x => x.count) : [1];

        return new Chart(canvas, {
            type: "doughnut",
            data: {
                labels,
                datasets: [{
                    label,
                    data: values,
                    backgroundColor: labels.map((_, i) => SERIES[i % SERIES.length]),
                    borderWidth: 0
                }]
            },
            plugins: [DoughnutPercentPlugin],
            options: GetDoughnutOptions()
        });
    };

    const UpsertComboChart = (chartRef, canvasId, labels, barValues, lineValues) => {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return chartRef;

        DestroyChart(chartRef);

        const x = labels.length ? labels : ["No data"];
        const bars = barValues.length ? barValues : [0];
        const line = lineValues.length ? lineValues : [0];

        return new Chart(canvas, {
            data: {
                labels: x,
                datasets: [
                    {
                        type: "bar",
                        label: "Ideas",
                        data: bars,
                        backgroundColor: C.navy,
                        borderRadius: 6,
                        maxBarThickness: 36
                    },
                    {
                        type: "line",
                        label: "Rate %",
                        data: line,
                        borderColor: C.orange,
                        backgroundColor: C.orange,
                        borderWidth: 2.5,
                        tension: 0.35,
                        pointRadius: 3,
                        yAxisID: "y1"
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: true, position: "bottom" } },
                scales: {
                    x: { grid: { display: false }, ticks: { autoSkip: false, maxRotation: 35, minRotation: 0 } },
                    y: { beginAtZero: true, grid: { color: "#eef0f4" } },
                    y1: {
                        position: "right",
                        beginAtZero: true,
                        max: 100,
                        grid: { display: false },
                        ticks: { callback: (v) => `${v}%` }
                    }
                }
            }
        });
    };

    const RenderLeadershipSignals = (totalRecords, stageItems, kpis) => {
        const total = ToNumber(kpis?.valid ?? totalRecords);
        const approved = ToNumber(kpis?.approved ?? GetStageCount(stageItems, "Approved"));
        const implemented = ToNumber(kpis?.implemented ?? GetStageCount(stageItems, "Implemented"));
        const backlog = ToNumber(kpis?.backlog ?? GetStageCount(stageItems, "In Approval"));

        const approvalRate = total ? approved / total : 0;
        const implRate = total ? implemented / total : 0;
        const apprToImpl = approved ? implemented / approved : 0;
        const backlogRate = total ? backlog / total : 0;

        const aiIdeation = ToNumber(kpis?.aiIdeation ?? 0);
        const aiSolution = ToNumber(kpis?.aiSolution ?? 0);
        const aiBenefitEst = ToNumber(kpis?.aiBenefitEst ?? 0);
        const realized = ToNumber(kpis?.realized ?? 0);
        //const pipeline = ToNumber(kpis?.pipeline ?? 0);
        const pipeline = ToNumber(kpis?.weightedPipeline ?? kpis?.pipeline ?? 0);
        const forecast = ToNumber(kpis?.forecast ?? (realized + pipeline));
        const approvedAiBenefit = ToNumber(kpis?.approvedAiBenefit ?? 0);
        const nonAiApprovedBenefit = ToNumber(kpis?.nonAiApprovedBenefit ?? 0);

        $("#kpiIdeasRaised").text(FormatN(total));
        $("#kpiApprovalRate").text(FormatPct(approvalRate));
        $("#kpiApprovedCount").text(FormatN(approved));
        $("#kpiImplRate").text(FormatPct(implRate));
        $("#kpiImplementedCount").text(FormatN(implemented));
        $("#kpiApprToImpl").text(FormatPct(apprToImpl));
        $("#kpiBacklogRate").text(FormatPct(backlogRate));
        $("#kpiBacklogCount").text(FormatN(backlog));

        $("#aiIdeationCount").text(FormatN(aiIdeation));
        $("#aiSolutionCount").text(FormatN(aiSolution));
        $("#aiBenefitValue").text("$" + FormatCompact(aiBenefitEst));
        $("#approvedAiValue").text("$" + FormatCompact(approvedAiBenefit));
        $("#nonAiValue").text("Non-AI approved $" + FormatCompact(nonAiApprovedBenefit));

        const $badge = $("#kpiBacklogBadge");
        $badge.removeClass("b-green b-amber b-red b-grey");

        if (backlogRate <= 0.10) {
            $badge.addClass("b-green").text("On target");
        } else if (backlogRate <= 0.20) {
            $badge.addClass("b-amber").text("At risk");
        } else {
            $badge.addClass("b-red").html(`
        <img src="/images/icons/breached.svg" class="ico" alt="" aria-hidden="true" />
        Breached`);
        }

        $("#sigIdeaHeadline").text(`${FormatN(aiIdeation)} AI ideas at ideation · ${FormatN(aiSolution)} AI as a solution`);
        $("#sigIdeaMeaning").text(`Of ${FormatN(total)} ideas, ${FormatN(aiIdeation)} were raised under the AI-first program and ${FormatN(aiSolution)} are confirmed AI solutions on review. Estimated AI benefit stands at ${FormatCompact(aiBenefitEst)}.`);

        $("#sigGovernanceHeadline").text(`${FormatPct(backlogRate)} of ideas sit in the approval backlog`);
        $("#sigGovernanceMeaning").text(`${FormatN(backlog)} ideas await a manager or ambassador decision. Split into within-SLA, at-risk and breached before acting.`);

        $("#sigConversionHeadline").text(`${FormatPct(apprToImpl)} of approved ideas reach implementation`);
        $("#sigConversionMeaning").text(`Approximately ${FormatN(Math.max(approved - implemented, 0))} approved ideas are not yet implemented.`);

        $("#sigValueHeadline").text(
            `${FormatCompact(realized)} realized · ${FormatCompact(pipeline)} weighted pipeline · ${FormatCompact(forecast)} forecast`
        );

        const $gov = $("#sigGovernanceCard");
        $gov.removeClass("s-green s-amber s-red").addClass(backlogRate > 0.20 ? "s-red" : backlogRate > 0.10 ? "s-amber" : "s-green");

        const $conv = $("#sigConversionCard");
        $conv.removeClass("s-green s-amber").addClass(apprToImpl < 0.5 ? "s-amber" : "s-green");
    };

    const RenderAiSplitChart = (totalRecords, kpis) => {
        const total = ToNumber(kpis?.valid ?? totalRecords);
        const aiIdeation = ToNumber(kpis?.aiIdeation ?? 0);
        const aiSolution = ToNumber(kpis?.aiSolution ?? 0);

        const nonAiIdeation = ToNumber(kpis?.nonAiIdeation ?? Math.max(total - aiIdeation, 0));
        const nonAiSolution = ToNumber(kpis?.nonAiSolution ?? Math.max(total - aiSolution, 0));

        const items = [
            { name: "AI ideation", count: aiIdeation },
            { name: "AI solution", count: aiSolution },
            { name: "Non-AI ideation", count: nonAiIdeation },
            { name: "Non-AI solution", count: nonAiSolution }
        ];

        aiSplitChart = UpsertBarChart(aiSplitChart, "cxAiSplit", "AI vs non-AI ideas", items, C.navy2);
    };

    const RenderCbaChart = (kpis) => {
    const approvedAiBenefit = ToNumber(kpis?.approvedAiBenefit ?? 0);
    const nonAiApprovedBenefit = ToNumber(kpis?.nonAiApprovedBenefit ?? 0);

    const items = [
        { name: "AI", count: approvedAiBenefit },
        { name: "Non-AI", count: nonAiApprovedBenefit }
    ];

    cbaChart = UpsertBarChart(cbaChart, "cxCBA", "CBA of approved projects", items, C.teal, true);
};

    const RenderTrendChart = (trendItems, totalRecords) => {
        const bars = new Array(12).fill(0);
        const line = new Array(12).fill(0);

        const safeItems = Array.isArray(trendItems) ? trendItems : [];
        let mappedCount = 0;

        safeItems.forEach((x) => {
            const idx = GetMonthIndex(x?.name);
            if (idx === -1) return;

            const count = ToNumber(x?.count);
            bars[idx] = count;

            // if backend provides explicit approval rate (0-100), use it; else fallback formula
            const explicitRate = x?.rate ?? x?.approvalRate ?? null;
            line[idx] = explicitRate !== null && explicitRate !== undefined
                ? ToNumber(explicitRate)
                : (totalRecords ? (count / totalRecords) * 100 : 0);

            mappedCount++;
        });

        // fallback: kung walang month names from API, gamitin order ng first 12 items
        if (mappedCount === 0 && safeItems.length > 0) {
            safeItems.slice(0, 12).forEach((x, i) => {
                const count = ToNumber(x?.count);
                bars[i] = count;
                line[i] = totalRecords ? (count / totalRecords) * 100 : 0;
            });
        }

        trendChart = UpsertComboChart(trendChart, "cxTrend", MONTH_LABELS, bars, line);
    };

    const RenderMixChart = (stageItems) => {
        mixChart = UpsertDoughnutChart(mixChart, "cxMix", "Portfolio funnel", SortStageItems(stageItems));
    };

    //const RenderRejectChart = (priorityItems) => {
    //    rejectChart = UpsertBarChart(rejectChart, "cxReject", "Rejection reasons", SortByCountDesc(priorityItems).slice(0, 8), C.red);
    //};

    //const RenderRejectByChart = (geoItems) => {
    //    rejectByChart = UpsertDoughnutChart(rejectByChart, "cxRejectBy", "Where rejection happens", SortByCountDesc(geoItems).slice(0, 6));
    //};

    const RenderRejectByChart = (rejectByItems) => {
        rejectByChart = UpsertDoughnutChart(
            rejectByChart,
            "cxRejectBy",
            "Where rejection happens",
            SortByCountDesc(rejectByItems).slice(0, 6)
        );
    };

    const RenderEmptyCharts = () => {
        aiSplitChart = UpsertBarChart(aiSplitChart, "cxAiSplit", "AI vs non-AI ideas", [], C.navy2);
        cbaChart = UpsertBarChart(cbaChart, "cxCBA", "CBA of approved projects", [], C.teal, true);
        trendChart = UpsertComboChart(trendChart, "cxTrend", [], [], []);
        mixChart = UpsertDoughnutChart(mixChart, "cxMix", "Portfolio funnel", []);
        rejectChart = UpsertBarChart(rejectChart, "cxReject", "Rejection reasons", [], C.red);
        rejectByChart = UpsertDoughnutChart(rejectByChart, "cxRejectBy", "Where rejection happens", []);
    };

    const BuildEffectiveFilters = (filters) => {
        const globalFilters = window.CommonFilters && typeof window.CommonFilters.getValues === "function"
            ? window.CommonFilters.getValues()
            : {};

        // allow direct weight object from forecastConfigApplied too
        const directWeights = {
            inApproval: filters?.inApproval,
            approvedNoOwner: filters?.approvedNoOwner,
            approvedWithPlan: filters?.approvedWithPlan,
            inImplementation: filters?.inImplementation,
            implementedNotValidated: filters?.implementedNotValidated,
            validated: filters?.validated
        };

        return {
            ...globalFilters,
            ...(filters || {}),
            ...Object.fromEntries(Object.entries(directWeights).filter(([, v]) => v !== undefined && v !== null))
        };
    };

    const LoadLeadershipCockpit = (filters) => {
        const start = performance.now();
        const effectiveFilters = BuildEffectiveFilters(filters);
        $.ajax({
            url: API_URL,
            type: "GET",
            cache: true,
            data: GetPayload(effectiveFilters),
            
            success: (response) => {
                console.log(
                    "API Time:",
                    (performance.now() - start).toFixed(0),
                    "ms"
                ); 
                const renderStart = performance.now();
                const totalRecords = response?.totalRecords ?? response?.TotalRecords ?? 0;

                const trend = NormalizeItems(response?.monthly ?? response?.Monthly ?? response?.capability ?? response?.Capability);
                const rejectBy = NormalizeItems(response?.rejectBy ?? response?.RejectBy);

                const rawRejectionReason = NormalizeItems(response?.rejectionReason ?? response?.RejectionReason);
                const fallbackPriority = NormalizeItems(response?.priority ?? response?.Priority);
                const rejectionReason = rawRejectionReason.length ? rawRejectionReason : fallbackPriority;

                const stage = NormalizeItems(response?.stage ?? response?.Stage);
                const kpis = response?.kpis ?? response?.Kpis ?? null;

                SetScopeCount(totalRecords);
                RenderLeadershipSignals(totalRecords, stage, kpis);

                RenderAiSplitChart(totalRecords, kpis);
                RenderCbaChart(kpis);
                RenderTrendChart(trend, totalRecords);
                RenderMixChart(stage);
                RenderRejectChart(rejectionReason);
                RenderRejectByChart(rejectBy);

                console.log(
                    "Render Time:",
                    (performance.now() - renderStart).toFixed(0),
                    "ms"
                );
            },
            error: (xhr) => {
                console.error("Failed to load dashboard data", xhr);
                SetScopeCount(0);
                RenderEmptyCharts();
            }
        });
    };

    const Attach_Filter_Events = () => {
        $(document)
            .off("commonFilterChanged.leadership")
            .on("commonFilterChanged.leadership", (_e, currentFilters) => {
                LoadLeadershipCockpit(currentFilters || {});
            });

        $(document)
            .off("forecastConfigApplied.leadership")
            .on("forecastConfigApplied.leadership", (_e, weights) => {
                const base = window.CommonFilters ? window.CommonFilters.getValues() : {};
                LoadLeadershipCockpit({ ...base, ...(weights || {}) });
            });
    };

    const Init_Leadership = () => {
        if (!window.CommonFilters && typeof Attach_Common_Events === "function") {
            Attach_Common_Events();
        } else if (!window.CommonFilters && typeof attach_common_events === "function") {
            attach_common_events();
        }

        const initialFilters = window.CommonFilters ? window.CommonFilters.getValues() : {};
        LoadLeadershipCockpit(initialFilters);
        Attach_Filter_Events();
    };

    Init_Leadership();
};