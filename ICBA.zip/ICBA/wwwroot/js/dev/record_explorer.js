﻿$(document).ready(() => Attach_RecordExplorer_Events());

const Attach_RecordExplorer_Events = () => {
    const API_URL = "RecordExplorer?handler=RecordExplorerData";
    const RECORD_PAGE_SIZE = 25;

    let RECORD_PAGE = 1;
    let RECORD_SELECTED_ID = "";
    let RECORD_SEARCH = "";
    let RECORD_SORT_COL = "IdeaID";
    let RECORD_SORT_DIR = "asc";
    let LOAD_TIMER = null;
    let RAW_ROWS = [];

    const RECORD_COLS = [
        "IdeaID", "CreatedOn", "Capability", "BusinessName", "Stage_Name", "__funnel",
        "enterprise priorities", "ThemeName", "Geo", "Hard Savings", "Soft Savings",
        "Pipeline Hard", "Pipeline Soft", "AmbassadorName", "IdeaValidated"
    ];

    let RECORD_VISIBLE_COLS = new Set([
        "IdeaID", "CreatedOn", "Capability", "BusinessName", "__funnel",
        "enterprise priorities", "ThemeName", "Geo", "Hard Savings", "Soft Savings", "IdeaValidated"
    ]);

    const ToNumber = (v) => Number.isNaN(Number(v)) ? 0 : Number(v);
    const FormatN = (n) => ToNumber(n).toLocaleString("en-US");

    const Esc = (v) => String(v ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");

    const SetScopeCount = (count) => {
        if (window.CommonFilters && typeof window.CommonFilters.setScopeCount === "function") {
            window.CommonFilters.setScopeCount(ToNumber(count));
        }
    };

    const GetPayload = (filters) => ({
        capability: filters?.capability || "",
        business: filters?.business || "",
        geo: filters?.geo || "",
        priority: filters?.priority || "",
        stage: filters?.stage || "",
        timeType: filters?.timeType || "all",
        year: filters?.year || "",
        start: filters?.start || "",
        end: filters?.end || ""
    });

    const BuildEffectiveFilters = (filters) => {
        const globalFilters = window.CommonFilters && typeof window.CommonFilters.getValues === "function"
            ? window.CommonFilters.getValues()
            : {};

        const directWeights = {
            inApproval: filters?.inApproval,
            approvedNoOwner: filters?.approvedNoOwner,
            approvedWithPlan: filters?.approvedWithPlan,
            inImplementation: filters?.inImplementation,
            implementedNotValidated: filters?.implementedNotValidated,
            validated: filters?.validated
        };

        return {
            ...globalFilters,
            ...(filters || {}),
            ...Object.fromEntries(Object.entries(directWeights).filter(([, v]) => v !== undefined && v !== null))
        };
    };

    const sortableValue = (row, col) => {
        const raw = row?.[col];
        if (col.includes("Savings") || col === "Days") return ToNumber(raw);
        return String(raw ?? "").toLowerCase();
    };

    const getRecordRows = () => {
        const q = RECORD_SEARCH.trim().toLowerCase();
        let out = RAW_ROWS;

        if (q) {
            out = out.filter(r => {
                const id = String(r?.IdeaID ?? "").toLowerCase();
                const title = String(r?.IdeaTitle ?? "").toLowerCase();
                return id.includes(q) || title.includes(q);
            });
        }

        const dir = RECORD_SORT_DIR === "asc" ? 1 : -1;
        out = [...out].sort((a, b) => {
            const av = sortableValue(a, RECORD_SORT_COL);
            const bv = sortableValue(b, RECORD_SORT_COL);

            if (typeof av === "number" && typeof bv === "number") {
                if (av !== bv) return (av - bv) * dir;
            } else {
                const cmp = String(av).localeCompare(String(bv));
                if (cmp !== 0) return cmp * dir;
            }

            return String(a?.IdeaID ?? "").localeCompare(String(b?.IdeaID ?? ""));
        });

        return out;
    };

    const RenderColumnPills = () => {
        const html = RECORD_COLS.map(c => {
            const checked = RECORD_VISIBLE_COLS.has(c) ? "checked" : "";
            const label = c === "__funnel" ? "Leadership Stage" : c;
            return `<label class="pill"><input type="checkbox" data-col="${Esc(c)}" ${checked} /> ${Esc(label)}</label>`;
        }).join("");

        $("#recCols").html(html);

        $("#recCols input[type='checkbox']").off("change").on("change", function () {
            const col = $(this).data("col");
            if (this.checked) RECORD_VISIBLE_COLS.add(col);
            else if (RECORD_VISIBLE_COLS.size > 1) RECORD_VISIBLE_COLS.delete(col);
            else this.checked = true;
            RenderTable();
        });
    };

    const RenderDetail = (rows, pageRows) => {
        let selected = rows.find(r => String(r?.IdeaID ?? "") === String(RECORD_SELECTED_ID ?? ""));
        if (!selected && pageRows.length) selected = pageRows[0];
        if (!selected) { $("#recDetail").html(""); return; }

        RECORD_SELECTED_ID = selected.IdeaID ?? "";

        $("#recDetail").html(`
            <div class="record-detail">
                <div class="section-head"><h2>Record Detail</h2><span class="hint">Evidence for selected idea ${Esc(selected["IdeaID"])}</span></div>
                <div class="detail-grid">
                    <div><div class="lbl">Idea ID</div><div class="val">${Esc(selected["IdeaID"])}</div></div>
                    <div><div class="lbl">Created On</div><div class="val">${Esc(selected["CreatedOn"])}</div></div>
                    <div><div class="lbl">Capability</div><div class="val">${Esc(selected["Capability"])}</div></div>
                    <div><div class="lbl">Business</div><div class="val">${Esc(selected["BusinessName"])}</div></div>
                    <div><div class="lbl">Source Stage</div><div class="val">${Esc(selected["Stage_Name"])}</div></div>
                    <div><div class="lbl">Leadership Stage</div><div class="val">${Esc(selected["__funnel"])}</div></div>
                    <div><div class="lbl">Priority</div><div class="val">${Esc(selected["enterprise priorities"])}</div></div>
                    <div><div class="lbl">Theme</div><div class="val">${Esc(selected["ThemeName"])}</div></div>
                    <div><div class="lbl">Geo</div><div class="val">${Esc(selected["Geo"])}</div></div>
                    <div><div class="lbl">Ambassador</div><div class="val">${Esc(selected["AmbassadorName"])}</div></div>
                    <div><div class="lbl">Hard Savings</div><div class="val">${Esc(selected["Hard Savings"])}</div></div>
                    <div><div class="lbl">Soft Savings</div><div class="val">${Esc(selected["Soft Savings"])}</div></div>
                </div>
            </div>
        `);
    };

    const RenderTable = () => {
        const rows = getRecordRows();
        const totalPages = Math.max(1, Math.ceil(rows.length / RECORD_PAGE_SIZE));
        if (RECORD_PAGE > totalPages) RECORD_PAGE = totalPages;
        if (RECORD_PAGE < 1) RECORD_PAGE = 1;

        const start = (RECORD_PAGE - 1) * RECORD_PAGE_SIZE;
        const pageRows = rows.slice(start, start + RECORD_PAGE_SIZE);
        const cols = RECORD_COLS.filter(c => RECORD_VISIBLE_COLS.has(c));

        const head = cols.map(c => {
            const label = c === "__funnel" ? "Leadership Stage" : c;
            const active = RECORD_SORT_COL === c;
            const marker = active ? (RECORD_SORT_DIR === "asc" ? "▲" : "▼") : "↕";
            return `<th><span class="th-sort" data-sort-col="${Esc(c)}">${Esc(label)} <span class="sort-marker${active ? " active" : ""}">${marker}</span></span></th>`;
        }).join("");
        $("#recHead").html(head);

        const body = pageRows.map(r => {
            const tds = cols.map(c => {
                const raw = r?.[c] ?? "";
                if (c === "IdeaID") return `<td><span class="row-link" data-idea-id="${Esc(r["IdeaID"])}">${Esc(raw)}</span></td>`;
                return `<td>${Esc(raw)}</td>`;
            }).join("");
            return `<tr>${tds}</tr>`;
        }).join("");

        $("#recBody").html(body || `<tr><td colspan="${Math.max(cols.length, 1)}" class="muted">No records match current filters.</td></tr>`);
        $("#recCountLabel").text(`${FormatN(rows.length)} matching records`);
        $("#recPageLabel").text(`Page ${RECORD_PAGE} of ${totalPages}`);

        $(".th-sort").off("click").on("click", function () {
            const col = $(this).data("sort-col");
            if (RECORD_SORT_COL === col) RECORD_SORT_DIR = RECORD_SORT_DIR === "asc" ? "desc" : "asc";
            else { RECORD_SORT_COL = col; RECORD_SORT_DIR = "asc"; }
            RECORD_PAGE = 1;
            RenderTable();
        });

        $(".row-link").off("click").on("click", function () {
            RECORD_SELECTED_ID = $(this).data("idea-id");
            RenderDetail(rows, pageRows);
        });

        RenderDetail(rows, pageRows);
    };

    const WireControls = () => {
        $("#recSearch").off("input").on("input", function () {
            RECORD_SEARCH = $(this).val() ?? "";
            RECORD_PAGE = 1;
            RenderTable();
        });

        $("#recPrev").off("click").on("click", () => {
            RECORD_PAGE = Math.max(1, RECORD_PAGE - 1);
            RenderTable();
        });

        $("#recNext").off("click").on("click", () => {
            const totalPages = Math.max(1, Math.ceil(getRecordRows().length / RECORD_PAGE_SIZE));
            RECORD_PAGE = Math.min(totalPages, RECORD_PAGE + 1);
            RenderTable();
        });
    };

    const LoadRecordExplorer = (filters) => {
        const effectiveFilters = BuildEffectiveFilters(filters);

        $.ajax({
            url: API_URL,
            type: "GET",
            cache: false,
            data: GetPayload(effectiveFilters),
            success: (response) => {
                RAW_ROWS = Array.isArray(response?.records) ? response.records : [];
                SetScopeCount(response?.totalRecords ?? 0);
                RECORD_PAGE = 1;
                RECORD_SELECTED_ID = "";
                RenderColumnPills();
                WireControls();
                RenderTable();
            },
            error: (xhr) => {
                console.error("Failed to load Record Explorer data", xhr);
                RAW_ROWS = [];
                SetScopeCount(0);
                RECORD_PAGE = 1;
                RECORD_SELECTED_ID = "";
                RenderColumnPills();
                WireControls();
                RenderTable();
            }
        });
    };

    const Attach_Filter_Events = () => {
        $(document)
            .off("commonFilterChanged.records")
            .on("commonFilterChanged.records", (_e, filters) => {
                if (LOAD_TIMER) clearTimeout(LOAD_TIMER);
                LOAD_TIMER = setTimeout(() => {
                    LoadRecordExplorer(filters || {});
                }, 250);
            });

        $(document)
            .off("forecastConfigApplied.records")
            .on("forecastConfigApplied.records", (_e, weights) => {
                const base = window.CommonFilters ? window.CommonFilters.getValues() : {};
                LoadRecordExplorer({ ...base, ...(weights || {}) });
            });
    };

    const Init_RecordExplorer = () => {
        if (!window.CommonFilters && typeof Attach_Common_Events === "function") {
            Attach_Common_Events();
        } else if (!window.CommonFilters && typeof attach_common_events === "function") {
            attach_common_events();
        }

        const filters = window.CommonFilters ? window.CommonFilters.getValues() : {};
        LoadRecordExplorer(filters);
        Attach_Filter_Events();
    };

    Init_RecordExplorer();
};