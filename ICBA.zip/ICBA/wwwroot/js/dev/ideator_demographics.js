﻿$(document).ready(() => Attach_IdeatorDemographics_Events());

const Attach_IdeatorDemographics_Events = () => {
    const API_URL = "IdeatorDemographics?handler=IdeatorDemographicsData";

    const C = {
        navy: "#002677",
        navy2: "#2f52a0",
        orange: "#e38a6e",
        teal: "#0f9d94",
        gold: "#f0a202",
        slate: "#6f7bbf",
        grey: "#c7ccd6",
        green: "#157a4a",
        red: "#b4231a"
    };

    const SERIES = [C.navy, C.orange, C.teal, C.gold, C.slate, C.green, C.red, C.grey];

    let capChart = null;
    let geoChart = null;
    let themeChart = null;
    let aiThemeChart = null;
    let loadTimer = null;

    const ToNumber = (v) => Number.isNaN(Number(v)) ? 0 : Number(v);
    const FormatN = (n) => ToNumber(n).toLocaleString("en-US");

    const DestroyChart = (c) => { if (c) c.destroy(); };

    const SetScopeCount = (count) => {
        if (window.CommonFilters && typeof window.CommonFilters.setScopeCount === "function") {
            window.CommonFilters.setScopeCount(ToNumber(count));
        }
    };

    const GetPayload = (filters) => ({
        capability: filters?.capability || "",
        business: filters?.business || "",
        geo: filters?.geo || "",
        priority: filters?.priority || "",
        stage: filters?.stage || "",
        timeType: filters?.timeType || "all",
        year: filters?.year || "",
        start: filters?.start || "",
        end: filters?.end || ""
    });

    const BuildEffectiveFilters = (filters) => {
        const globalFilters = window.CommonFilters && typeof window.CommonFilters.getValues === "function"
            ? window.CommonFilters.getValues()
            : {};

        const directWeights = {
            inApproval: filters?.inApproval,
            approvedNoOwner: filters?.approvedNoOwner,
            approvedWithPlan: filters?.approvedWithPlan,
            inImplementation: filters?.inImplementation,
            implementedNotValidated: filters?.implementedNotValidated,
            validated: filters?.validated
        };

        return {
            ...globalFilters,
            ...(filters || {}),
            ...Object.fromEntries(Object.entries(directWeights).filter(([, v]) => v !== undefined && v !== null))
        };
    };

    const Get = (obj, camel, pascal) => obj?.[camel] ?? obj?.[pascal];

    const NormalizeItems = (items) => {
        if (!Array.isArray(items)) return [];
        return items.map(x => ({
            name: x?.name ?? x?.Name ?? "",
            count: ToNumber(x?.count ?? x?.Count)
        }));
    };

    const RenderKpis = (kpis) => {
        $("#uxContributors").text(FormatN(Get(kpis, "contributors", "Contributors") ?? 0));
        $("#uxIdeasPerContributor").text(ToNumber(Get(kpis, "ideasPerContributor", "IdeasPerContributor") ?? 0).toFixed(1));
        $("#uxCapabilities").text(FormatN(Get(kpis, "capabilitiesEngaged", "CapabilitiesEngaged") ?? 0));
        $("#uxGeographies").text(FormatN(Get(kpis, "geographies", "Geographies") ?? 0));
    };

    const RenderCapChart = (items) => {
        const canvas = document.getElementById("uxCap");
        if (!canvas) return;
        DestroyChart(capChart);

        capChart = new Chart(canvas, {
            type: "bar",
            data: {
                labels: items.map(x => x.name),
                datasets: [{
                    data: items.map(x => x.count),
                    backgroundColor: C.navy,
                    borderRadius: 4,
                    maxBarThickness: 30
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { beginAtZero: true },
                    x: { grid: { display: false }, ticks: { autoSkip: false, maxRotation: 40, minRotation: 0 } }
                }
            }
        });
    };

    const RenderGeoChart = (items) => {
        const canvas = document.getElementById("uxGeo");
        if (!canvas) return;
        DestroyChart(geoChart);

        geoChart = new Chart(canvas, {
            type: "doughnut",
            data: {
                labels: items.map(x => x.name),
                datasets: [{
                    data: items.map(x => x.count),
                    backgroundColor: items.map((_, i) => SERIES[i % SERIES.length]),
                    borderWidth: 0
                }]
            },
            plugins: [DoughnutPercentPlugin],
            options: DoughnutOptions("60%")
        });
    };

    const RenderThemeChart = (items) => {
        const canvas = document.getElementById("uxTheme");
        if (!canvas) return;
        DestroyChart(themeChart);

        themeChart = new Chart(canvas, {
            type: "bar",
            data: {
                labels: items.map(x => x.name),
                datasets: [{
                    label: "Ideas",
                    data: items.map(x => x.count),
                    backgroundColor: C.navy2,
                    borderRadius: 4,
                    maxBarThickness: 24
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: "y",
                plugins: { legend: { display: false } },
                scales: {
                    x: { beginAtZero: true },
                    y: { grid: { display: false } }
                }
            }
        });
    };

    const RenderAiThemeChart = (items) => {
        const canvas = document.getElementById("uxAiTheme");
        if (!canvas) return;
        DestroyChart(aiThemeChart);

        aiThemeChart = new Chart(canvas, {
            type: "doughnut",
            data: {
                labels: items.map(x => x.name),
                datasets: [{
                    data: items.map(x => x.count),
                    backgroundColor: items.map((_, i) => SERIES[i % SERIES.length]),
                    borderWidth: 0
                }]
            },
            plugins: [DoughnutPercentPlugin],
            options: DoughnutOptions("58%")
        });
    };

    const DoughnutPercentPlugin = {
        id: "doughnutPercentLabels",
        afterDatasetsDraw: (chart) => {
            const dataset = chart?.data?.datasets?.[0];
            if (!dataset) return;

            const raw = (dataset.data || []).map(ToNumber);
            const visibleData = raw.map((v, i) => (chart.getDataVisibility(i) ? v : 0));
            const total = visibleData.reduce((sum, v) => sum + v, 0);
            if (!total) return;

            const meta = chart.getDatasetMeta(0);
            const { ctx } = chart;

            ctx.save();
            ctx.fillStyle = "#ffffff";
            ctx.font = "600 11px Segoe UI";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";

            meta.data.forEach((arc, i) => {
                if (!chart.getDataVisibility(i)) return;
                const val = visibleData[i];
                if (val <= 0) return;

                const pct = (val / total) * 100;
                if (pct < 4) return;

                const { x, y } = arc.tooltipPosition();
                ctx.fillText(`${pct.toFixed(1)}%`, x, y);
            });

            ctx.restore();
        }
    };

    const DoughnutOptions = (cutout) => ({
        responsive: true,
        maintainAspectRatio: false,
        cutout,
        plugins: {
            legend: {
                position: "bottom",
                labels: {
                    usePointStyle: true,
                    pointStyle: "circle",
                    boxWidth: 10,
                    boxHeight: 10,
                    font: { size: 10 }
                }
            },
            tooltip: {
                callbacks: {
                    label: (ctx) => {
                        const val = ToNumber(ctx.raw);
                        const total = (ctx.dataset.data || []).reduce((s, v, i) =>
                            s + (ctx.chart.getDataVisibility(i) ? ToNumber(v) : 0), 0);
                        const pct = total ? ((val / total) * 100).toFixed(1) : "0.0";
                        return `${ctx.label}: ${val.toLocaleString("en-US")} (${pct}%)`;
                    }
                }
            }
        }
    });

    const LoadIdeatorDemographics = (filters) => {
        const effectiveFilters = BuildEffectiveFilters(filters);

        $.ajax({
            url: API_URL,
            type: "GET",
            cache: false,
            data: GetPayload(effectiveFilters),
            success: (response) => {
                SetScopeCount(Get(response, "totalRecords", "TotalRecords") ?? 0);

                const kpis = Get(response, "kpis", "Kpis") ?? {};
                const capabilityIdeas = NormalizeItems(Get(response, "capabilityIdeas", "CapabilityIdeas"));
                const geoIdeas = NormalizeItems(Get(response, "geoIdeas", "GeoIdeas"));
                const themeIdeas = NormalizeItems(Get(response, "themeIdeas", "ThemeIdeas"));
                const aiTheme = NormalizeItems(Get(response, "aiTheme", "AiTheme"));

                RenderKpis(kpis);
                RenderCapChart(capabilityIdeas);
                RenderGeoChart(geoIdeas);
                RenderThemeChart(themeIdeas);
                RenderAiThemeChart(aiTheme);
            },
            error: (xhr) => {
                console.error("Failed to load Ideator Demographics data", xhr);
                SetScopeCount(0);
                RenderKpis({});
                RenderCapChart([]);
                RenderGeoChart([]);
                RenderThemeChart([]);
                RenderAiThemeChart([]);
            }
        });
    };

    const Attach_Filter_Events = () => {
        $(document)
            .off("commonFilterChanged.ideator")
            .on("commonFilterChanged.ideator", (_e, filters) => {
                if (loadTimer) clearTimeout(loadTimer);
                loadTimer = setTimeout(() => {
                    LoadIdeatorDemographics(filters || {});
                }, 250);
            });

        $(document)
            .off("forecastConfigApplied.ideator")
            .on("forecastConfigApplied.ideator", (_e, weights) => {
                const base = window.CommonFilters ? window.CommonFilters.getValues() : {};
                LoadIdeatorDemographics({ ...base, ...(weights || {}) });
            });
    };

    const Init_IdeatorDemographics = () => {
        if (!window.CommonFilters && typeof Attach_Common_Events === "function") {
            Attach_Common_Events();
        } else if (!window.CommonFilters && typeof attach_common_events === "function") {
            attach_common_events();
        }

        const filters = window.CommonFilters ? window.CommonFilters.getValues() : {};
        LoadIdeatorDemographics(filters);
        Attach_Filter_Events();
    };

    Init_IdeatorDemographics();
};