﻿$(document).ready(() => Attach_GovernanceFlow_Events());

const Attach_GovernanceFlow_Events = () => {
    const API_URL = "GovernanceFlow?handler=GovernanceFlowData";

    const C = {
        orange: "#e38a6e",
        navy: "#002677",
        navy2: "#2f52a0",
        teal: "#0f9d94",
        gold: "#f0a202",
        slate: "#6f7bbf",
        grey: "#c7ccd6",
        green: "#157a4a",
        amber: "#a86300",
        red: "#b4231a"
    };

    const SERIES = [C.navy, C.orange, C.teal, C.gold, C.slate, C.green, C.red, C.grey];
    const STAGE_ORDER = ["Draft", "In Approval", "Approved", "In Implementation", "Implemented", "Rejected"];

    let funnelChart = null;
    let capChart = null;
    let driversChart = null;
    let whoChart = null;
    let aiCapChart = null;
    let reasonChart = null;
    let loadTimer = null;

    const ToNumber = (value) => {
        const n = Number(value);
        return Number.isNaN(n) ? 0 : n;
    };

    const FormatN = (n) => ToNumber(n).toLocaleString("en-US");
    const FormatPct = (n) => `${(ToNumber(n) * 100).toFixed(1)}%`;

    const GetPayload = (filters) => ({
        capability: filters?.capability || "",
        business: filters?.business || "",
        geo: filters?.geo || "",
        priority: filters?.priority || "",
        stage: filters?.stage || "",
        timeType: filters?.timeType || "all",
        year: filters?.year || "",
        start: filters?.start || "",
        end: filters?.end || ""
    });

    const BuildEffectiveFilters = (filters) => {
        const globalFilters = window.CommonFilters && typeof window.CommonFilters.getValues === "function"
            ? window.CommonFilters.getValues()
            : {};

        const directWeights = {
            inApproval: filters?.inApproval,
            approvedNoOwner: filters?.approvedNoOwner,
            approvedWithPlan: filters?.approvedWithPlan,
            inImplementation: filters?.inImplementation,
            implementedNotValidated: filters?.implementedNotValidated,
            validated: filters?.validated
        };

        return {
            ...globalFilters,
            ...(filters || {}),
            ...Object.fromEntries(Object.entries(directWeights).filter(([, v]) => v !== undefined && v !== null))
        };
    };

    const NormalizeItems = (items) => {
        if (!Array.isArray(items)) return [];
        return items
            .map(x => ({
                name: (x?.name ?? x?.Name ?? "").toString().trim(),
                count: ToNumber(x?.count ?? x?.Count ?? 0)
            }))
            .filter(x => x.name.length > 0);
    };

    const SortByCountDesc = (items) =>
        [...items].sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));

    const SetScopeCount = (count) => {
        if (window.CommonFilters && typeof window.CommonFilters.setScopeCount === "function") {
            window.CommonFilters.setScopeCount(ToNumber(count));
        }
    };

    const DestroyChart = (chartRef) => {
        if (chartRef) chartRef.destroy();
    };

    const GetBarOptions = (horizontal = false, showLegend = false) => ({
        responsive: true,
        maintainAspectRatio: false,
        indexAxis: horizontal ? "y" : "x",
        plugins: {
            legend: { display: showLegend, position: "bottom" },
            tooltip: { mode: "index", intersect: false }
        },
        scales: horizontal
            ? {
                x: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: "#eef0f4" } },
                y: { grid: { display: false }, ticks: { autoSkip: false } }
            }
            : {
                x: { grid: { display: false }, ticks: { autoSkip: false, maxRotation: 35, minRotation: 0 } },
                y: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: "#eef0f4" } }
            }
    });

    const DoughnutPercentPlugin = {
        id: "doughnutPercentLabels",
        afterDatasetsDraw: (chart, _args, pluginOptions) => {
            const dataset = chart?.data?.datasets?.[0];
            if (!dataset) return;

            const data = (dataset.data || []).map(ToNumber);
            const total = data.reduce((sum, v) => sum + ToNumber(v), 0);
            if (!total) return;

            const meta = chart.getDatasetMeta(0);
            const { ctx } = chart;

            ctx.save();
            ctx.fillStyle = pluginOptions?.color || "#ffffff";
            ctx.font = pluginOptions?.font || "600 11px Segoe UI";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";

            meta.data.forEach((arc, i) => {
                const val = ToNumber(data[i]);
                if (val <= 0) return;
                const pct = (val / total) * 100;
                if (pct < 4) return;

                const { x, y } = arc.tooltipPosition();
                ctx.fillText(`${pct.toFixed(1)}%`, x, y);
            });

            ctx.restore();
        }
    };

    const GetDoughnutOptions = () => ({
        responsive: true,
        maintainAspectRatio: false,
        cutout: "62%",
        plugins: {
            legend: {
                display: true,
                position: "bottom",
                labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true }
            },
            tooltip: {
                callbacks: {
                    label: (ctx) => {
                        const val = ToNumber(ctx.raw);
                        const total = (ctx.dataset.data || []).reduce((s, v) => s + ToNumber(v), 0);
                        const pct = total ? ((val / total) * 100).toFixed(1) : "0.0";
                        return `${ctx.label}: ${val.toLocaleString("en-US")} (${pct}%)`;
                    }
                }
            },
            doughnutPercentLabels: {
                color: "#ffffff",
                font: "600 11px Segoe UI"
            }
        }
    });

    const UpsertBarChart = (chartRef, canvasId, label, items, color, horizontal = false, showLegend = false) => {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return chartRef;

        DestroyChart(chartRef);

        const safeItems = Array.isArray(items) ? items : [];
        const labels = safeItems.length ? safeItems.map(x => x.name) : ["No data"];
        const values = safeItems.length ? safeItems.map(x => x.count) : [0];

        return new Chart(canvas, {
            type: "bar",
            data: {
                labels,
                datasets: [{
                    label,
                    data: values,
                    backgroundColor: color,
                    borderRadius: 6,
                    maxBarThickness: 36
                }]
            },
            options: GetBarOptions(horizontal, showLegend)
        });
    };

    const UpsertStackedBar = (chartRef, canvasId, labels, datasets) => {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return chartRef;

        DestroyChart(chartRef);

        const safeLabels = Array.isArray(labels) && labels.length ? labels : ["No data"];
        const safeDatasets = Array.isArray(datasets) && datasets.length
            ? datasets
            : [{ label: "No data", data: [0], backgroundColor: C.grey }];

        return new Chart(canvas, {
            type: "bar",
            data: { labels: safeLabels, datasets: safeDatasets },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: "y",
                plugins: { legend: { display: true, position: "bottom" } },
                scales: {
                    x: { stacked: true, beginAtZero: true, grid: { color: "#eef0f4" } },
                    y: { stacked: true, grid: { display: false } }
                }
            }
        });
    };

    const UpsertDoughnut = (chartRef, canvasId, label, items) => {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return chartRef;

        DestroyChart(chartRef);

        const safeItems = Array.isArray(items) ? items : [];
        const labels = safeItems.length ? safeItems.map(x => x.name) : ["No data"];
        const values = safeItems.length ? safeItems.map(x => x.count) : [1];

        return new Chart(canvas, {
            type: "doughnut",
            data: {
                labels,
                datasets: [{
                    label,
                    data: values,
                    backgroundColor: labels.map((_, i) => SERIES[i % SERIES.length]),
                    borderWidth: 0
                }]
            },
            plugins: [DoughnutPercentPlugin],
            options: GetDoughnutOptions()
        });
    };

    const RenderKpis = (totalRecords, stageItems, kpis) => {
        const total = ToNumber(kpis?.valid ?? totalRecords);
        const approved = ToNumber(kpis?.approved ?? stageItems.find(x => x.name === "Approved")?.count ?? 0);
        const rejected = ToNumber(kpis?.rejected ?? stageItems.find(x => x.name === "Rejected")?.count ?? 0);
        const backlog = ToNumber(kpis?.backlog ?? stageItems.find(x => x.name === "In Approval")?.count ?? 0);

        const approvalRate = total ? approved / total : 0;
        const rejectRate = total ? rejected / total : 0;
        const backlogRate = total ? backlog / total : 0;
        const avgDecisionAge = ToNumber(kpis?.avgDecisionAge ?? 0);

        $("#gfValidCount").text(FormatN(total));
        $("#gfApprovedCount").text(FormatN(approved));
        $("#gfRejectedCount").text(FormatN(rejected));
        $("#gfBacklogCount").text(FormatN(backlog));

        $("#gfApprovalRate").text(FormatPct(approvalRate));
        $("#gfRejectRate").text(FormatPct(rejectRate));
        $("#gfBacklogRate").text(FormatPct(backlogRate));
        $("#gfDecisionAge").text(avgDecisionAge.toFixed(1));

        const $badge = $("#gfBacklogBadge");
        $badge.removeClass("b-green b-amber b-red b-grey");
        if (backlogRate <= 0.10) $badge.addClass("b-green").text("On target");
        else if (backlogRate <= 0.20) $badge.addClass("b-amber").text("At risk");
        else $badge.addClass("b-red").text("Breached");
    };

    const RenderLeadershipFunnel = (stageItems) => {
        const canvas = document.getElementById("gxFunnel");
        if (!canvas) return;

        DestroyChart(funnelChart);

        const map = new Map((stageItems || []).map(x => [x.name, ToNumber(x.count)]));
        const items = STAGE_ORDER.map(stage => ({ stage, count: map.get(stage) ?? 0 }));

        const total = items.reduce((s, x) => s + x.count, 0);
        const maxCount = Math.max(...items.map(x => x.count), 1);

        const RightValueLabelsPlugin = {
            id: "rightValueLabels",
            afterDatasetsDraw: (chart) => {
                const metaBlue = chart.getDatasetMeta(1);
                const blueData = chart.data.datasets[1].data || [];
                const { ctx, chartArea } = chart;

                const countX = chartArea.right + 62;
                const pctX = chartArea.right + 68;

                ctx.save();
                ctx.fillStyle = "#334155";
                ctx.font = "600 11px Segoe UI";
                ctx.textBaseline = "middle";

                metaBlue.data.forEach((bar, i) => {
                    const val = ToNumber(blueData[i]);
                    const pct = total ? (val / total) * 100 : 0;
                    const y = bar.y;

                    ctx.textAlign = "right";
                    ctx.fillText(FormatN(val), countX, y);

                    ctx.textAlign = "left";
                    ctx.fillText(` (${pct.toFixed(1)}%)`, pctX, y);
                });

                ctx.restore();
            }
        };

        funnelChart = new Chart(canvas, {
            type: "bar",
            data: {
                labels: items.map(x => x.stage),
                datasets: [
                    {
                        label: "Track",
                        data: items.map(() => maxCount),
                        backgroundColor: "rgba(199, 204, 214, 0.55)",
                        borderRadius: 7,
                        grouped: false,
                        barThickness: 24,
                        order: 1
                    },
                    {
                        label: "Current-stage distribution",
                        data: items.map(x => x.count),
                        backgroundColor: C.navy,
                        borderColor: C.navy,
                        borderWidth: 1,
                        borderRadius: 7,
                        borderSkipped: false,
                        grouped: false,
                        barThickness: 14,
                        order: 99
                    }
                ]
            },
            plugins: [RightValueLabelsPlugin],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: "y",
                layout: { padding: { right: 170 } },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => {
                                if (ctx.datasetIndex === 0) return null;
                                const v = ToNumber(ctx.raw);
                                const pct = total ? (v / total) * 100 : 0;
                                return `${FormatN(v)} (${pct.toFixed(1)}%)`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        max: maxCount,
                        grid: { display: false },
                        ticks: { display: false }
                    },
                    y: {
                        grid: { display: false },
                        ticks: { autoSkip: false }
                    }
                }
            }
        });
    };

    const GetAgeTone = (avgDays) => {
        const d = ToNumber(avgDays);
        if (d <= 15) return "green";
        if (d <= 30) return "amber";
        return "red";
    };

    const RenderApprovalProcessTable = (response, kpis) => {
        const rows = Array.isArray(response?.processOwners ?? response?.ProcessOwners)
            ? (response?.processOwners ?? response?.ProcessOwners)
            : [];

        const $tbody = $("#gfApprovalProcessBody");
        if (!$tbody.length) return;

        if (!rows.length) {
            $tbody.html(`
                <tr>
                    <td colspan="4" class="muted">No data available</td>
                </tr>
            `);
            return;
        }

        const html = rows.map(r => {
            const pending = ToNumber(r?.pending);
            const avgDays = ToNumber(r?.avgDays ?? kpis?.avgDecisionAge ?? 0);
            const tone = GetAgeTone(avgDays);

            return `
                <tr>
                    <td class="strong">${r?.step ?? "-"}</td>
                    <td>${r?.owner ?? "-"}</td>
                    <td class="num">${FormatN(pending)}</td>
                    <td class="num"><span class="badge b-${tone}">${avgDays.toFixed(1)} days</span></td>
                </tr>
            `;
        }).join("");

        $tbody.html(html);
    };

    const RenderCharts = (response, stageItems) => {
        RenderLeadershipFunnel(stageItems);

        const capabilityBacklog = NormalizeItems(response?.capabilityBacklog ?? response?.CapabilityBacklog);
        const backlogDrivers = NormalizeItems(response?.backlogStep ?? response?.BacklogStep);
        const rejectBy = NormalizeItems(response?.rejectBy ?? response?.RejectBy);
        const rejectionReason = NormalizeItems(response?.rejectionReason ?? response?.RejectionReason);

        const aiByCapability = Array.isArray(response?.aiByCapability ?? response?.AiByCapability)
            ? (response?.aiByCapability ?? response?.AiByCapability)
            : [];

        capChart = UpsertBarChart(capChart, "gxCap", "Backlog", SortByCountDesc(capabilityBacklog).slice(0, 8), C.orange, true, false);
        driversChart = UpsertBarChart(driversChart, "gxDrivers", "Waiting", SortByCountDesc(backlogDrivers).slice(0, 8), C.navy, true, false);
        whoChart = UpsertDoughnut(whoChart, "gxWho", "Backlog owner", SortByCountDesc(rejectBy).slice(0, 6));
        reasonChart = UpsertBarChart(reasonChart, "gxRejReason", "Rejected", SortByCountDesc(rejectionReason).slice(0, 8), C.red, true, false);

        if (aiByCapability.length) {
            const caps = [...new Set(aiByCapability.map(x => x?.capability).filter(Boolean))];
            const ideation = caps.map(c => ToNumber(aiByCapability.find(x => x.capability === c)?.aiIdeation ?? 0));
            const solution = caps.map(c => ToNumber(aiByCapability.find(x => x.capability === c)?.aiSolution ?? 0));

            aiCapChart = UpsertStackedBar(aiCapChart, "gxAiCap", caps, [
                { label: "AI at ideation", data: ideation, backgroundColor: C.navy, borderRadius: 4, maxBarThickness: 20 },
                { label: "AI as a solution", data: solution, backgroundColor: C.teal, borderRadius: 4, maxBarThickness: 20 }
            ]);
        } else {
            aiCapChart = UpsertStackedBar(aiCapChart, "gxAiCap", [], []);
        }
    };

    const LoadGovernanceFlow = (filters) => {
        const effectiveFilters = BuildEffectiveFilters(filters);

        $.ajax({
            url: API_URL,
            type: "GET",
            cache: false,
            data: GetPayload(effectiveFilters),

            success: (response) => {
                const totalRecords = response?.totalRecords ?? response?.TotalRecords ?? 0;
                const stage = NormalizeItems(response?.stage ?? response?.Stage);
                const kpis = response?.kpis ?? response?.Kpis ?? null;

                SetScopeCount(totalRecords);
                RenderKpis(totalRecords, stage, kpis);
                RenderApprovalProcessTable(response, kpis);
                RenderCharts(response, stage);
            },

            error: (xhr) => {
                console.error("Failed to load Governance Flow data", xhr);
                SetScopeCount(0);

                RenderKpis(0, [], {});
                $("#gfApprovalProcessBody").html(`
                    <tr>
                        <td colspan="4" class="muted">Unable to load data</td>
                    </tr>
                `);

                funnelChart = UpsertBarChart(funnelChart, "gxFunnel", "Leadership funnel", [], C.navy2, true);
                capChart = UpsertBarChart(capChart, "gxCap", "Backlog", [], C.orange, true);
                driversChart = UpsertBarChart(driversChart, "gxDrivers", "Waiting", [], C.navy, true);
                whoChart = UpsertDoughnut(whoChart, "gxWho", "Backlog owner", []);
                aiCapChart = UpsertStackedBar(aiCapChart, "gxAiCap", [], []);
                reasonChart = UpsertBarChart(reasonChart, "gxRejReason", "Rejected", [], C.red, true);
            }
        });
    };

    const Attach_Filter_Events = () => {
        $(document)
            .off("commonFilterChanged.governance")
            .on("commonFilterChanged.governance", (_e, filters) => {
                if (loadTimer) clearTimeout(loadTimer);
                loadTimer = setTimeout(() => {
                    LoadGovernanceFlow(filters || {});
                }, 250);
            });

        $(document)
            .off("forecastConfigApplied.governance")
            .on("forecastConfigApplied.governance", (_e, weights) => {
                const base = window.CommonFilters ? window.CommonFilters.getValues() : {};
                LoadGovernanceFlow({ ...base, ...(weights || {}) });
            });
    };

    const Init_Governance = () => {
        if (!window.CommonFilters && typeof Attach_Common_Events === "function") {
            Attach_Common_Events();
        } else if (!window.CommonFilters && typeof attach_common_events === "function") {
            attach_common_events();
        }

        const filters = window.CommonFilters ? window.CommonFilters.getValues() : {};
        LoadGovernanceFlow(filters);
        Attach_Filter_Events();
    };

    Init_Governance();
};