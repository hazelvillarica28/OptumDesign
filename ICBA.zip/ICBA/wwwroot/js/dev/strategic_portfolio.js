﻿$(document).ready(() => Attach_StrategicPortfolio_Events());

const Attach_StrategicPortfolio_Events = () => {

    const API_URL = "StrategicPortfolio?handler=StrategicPortfolioData";

    const C = {
        orange: "#e38a6e",
        navy: "#002677",
        navy2: "#2f52a0",
        teal: "#0f9d94",
        gold: "#f0a202",
        slate: "#6f7bbf",
        grey: "#c7ccd6",
        green: "#157a4a",
        amber: "#a86300",
        red: "#b4231a"
    };

    const SERIES = [
        C.navy,
        C.orange,
        C.teal,
        C.gold,
        C.slate,
        C.green,
        C.red,
        C.grey
    ];

    let priorityMixChart = null;
    let capabilityPriorityChart = null;
    let loadTimer = null;

    const ToNumber = (value) => {
        const n = Number(value);
        return Number.isNaN(n) ? 0 : n;
    };

    const FormatN = (n) =>
        ToNumber(n).toLocaleString("en-US");

    const DestroyChart = (chart) => {
        if (chart) chart.destroy();
    };

    const NormalizeItems = (items) => {
        if (!Array.isArray(items)) return [];

        return items.map(x => ({
            name: x?.name ?? "",
            count: ToNumber(x?.count),
            approvalRate: ToNumber(x?.approvalRate ?? 0)
        }));
    };

    const SetScopeCount = (count) => {
        if (
            window.CommonFilters &&
            typeof window.CommonFilters.setScopeCount === "function"
        ) {
            window.CommonFilters.setScopeCount(ToNumber(count));
        }
    };

    const GetPayload = (filters) => ({
        capability: filters?.capability || "",
        business: filters?.business || "",
        geo: filters?.geo || "",
        priority: filters?.priority || "",
        stage: filters?.stage || "",
        timeType: filters?.timeType || "all",
        year: filters?.year || "",
        start: filters?.start || "",
        end: filters?.end || ""
    });

    const BuildEffectiveFilters = (filters) => {
        const globalFilters = window.CommonFilters && typeof window.CommonFilters.getValues === "function"
            ? window.CommonFilters.getValues()
            : {};

        const directWeights = {
            inApproval: filters?.inApproval,
            approvedNoOwner: filters?.approvedNoOwner,
            approvedWithPlan: filters?.approvedWithPlan,
            inImplementation: filters?.inImplementation,
            implementedNotValidated: filters?.implementedNotValidated,
            validated: filters?.validated
        };

        return {
            ...globalFilters,
            ...(filters || {}),
            ...Object.fromEntries(
                Object.entries(directWeights).filter(([, v]) => v !== undefined && v !== null)
            )
        };
    };

    const DoughnutPercentPlugin = {
        id: "doughnutPercentLabels",
        afterDatasetsDraw: (chart, _args, pluginOptions) => {
            const dataset = chart?.data?.datasets?.[0];
            if (!dataset) return;

            const raw = (dataset.data || []).map(ToNumber);
            const visibleData = raw.map((v, i) => (chart.getDataVisibility(i) ? v : 0));
            const total = visibleData.reduce((sum, v) => sum + v, 0);
            if (!total) return;

            const meta = chart.getDatasetMeta(0);
            const { ctx } = chart;

            ctx.save();
            ctx.fillStyle = pluginOptions?.color || "#ffffff";
            ctx.font = pluginOptions?.font || "600 11px Segoe UI";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";

            meta.data.forEach((arc, i) => {
                if (!chart.getDataVisibility(i)) return;

                const val = visibleData[i];
                if (val <= 0) return;

                const pct = (val / total) * 100;
                if (pct < 4) return;

                const { x, y } = arc.tooltipPosition();
                ctx.fillText(`${pct.toFixed(1)}%`, x, y);
            });

            ctx.restore();
        }
    };

    const GetDoughnutOptions = () => ({
        responsive: true,
        maintainAspectRatio: false,
        cutout: "60%",
        plugins: {
            legend: {
                position: "bottom",
                labels: {
                    usePointStyle: true,
                    pointStyle: "circle",
                    boxWidth: 10,
                    boxHeight: 10
                }
            },
            tooltip: {
                callbacks: {
                    label: (ctx) => {
                        const val = ToNumber(ctx.raw);
                        const total = (ctx.dataset.data || []).reduce((s, v, i) => {
                            return s + (ctx.chart.getDataVisibility(i) ? ToNumber(v) : 0);
                        }, 0);

                        const pct = total ? ((val / total) * 100).toFixed(1) : "0.0";
                        return `${ctx.label}: ${val.toLocaleString("en-US")} (${pct}%)`;
                    }
                }
            },
            doughnutPercentLabels: {
                color: "#ffffff",
                font: "600 11px Segoe UI"
            }
        }
    });

    const RenderPriorityMix = (items) => {
        const canvas = document.getElementById("pxPrio");
        if (!canvas) return;

        DestroyChart(priorityMixChart);

        const safeItems = Array.isArray(items) ? items : [];
        const labels = safeItems.length ? safeItems.map(x => x.name) : ["No data"];
        const values = safeItems.length ? safeItems.map(x => ToNumber(x.count)) : [1];

        priorityMixChart = new Chart(canvas, {
            type: "doughnut",
            data: {
                labels,
                datasets: [{
                    data: values,
                    backgroundColor: labels.map((_, i) => SERIES[i % SERIES.length]),
                    borderWidth: 0
                }]
            },
            plugins: [DoughnutPercentPlugin],
            options: GetDoughnutOptions()
        });
    };

    const RenderCapabilityPriority = (rows) => {
        const canvas = document.getElementById("pxCapPrio");
        if (!canvas) return;

        DestroyChart(capabilityPriorityChart);

        const capabilities = [...new Set(rows.map(x => x.capability))];
        const priorities = [...new Set(rows.map(x => x.priority))];

        const datasets = priorities.map((priority, index) => ({
            label: priority,
            backgroundColor: SERIES[index % SERIES.length],
            borderRadius: 4,
            data: capabilities.map(capability => {
                const total = rows
                    .filter(x => x.capability === capability && x.priority === priority)
                    .reduce((sum, x) => sum + ToNumber(x.count), 0);
                return total;
            })
        }));

        capabilityPriorityChart = new Chart(canvas, {
            type: "bar",
            data: {
                labels: capabilities,
                datasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: "y",
                plugins: {
                    legend: {
                        position: "bottom",
                        labels: {
                            usePointStyle: true,
                            pointStyle: "circle",
                            boxWidth: 10,
                            boxHeight: 10
                        }
                    }
                },
                scales: {
                    x: {
                        stacked: true,
                        beginAtZero: true,
                        grid: {
                            color: "#eef0f4"
                        }
                    },
                    y: {
                        stacked: true,
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    };

    const RenderCapabilitySummary = (items, totalRecords) => {
        const $tbody = $("#capabilitySummaryBody");

        const safeItems = Array.isArray(items)
            ? [...items].sort((a, b) => b.count - a.count).slice(0, 10)
            : [];

        if (!safeItems.length) {
            $tbody.html(`
            <tr>
                <td colspan="4" class="muted">No data available</td>
            </tr>
        `);
            return;
        }

        let html = "";

        safeItems.forEach(x => {
            const count = ToNumber(x.count);
            const share = totalRecords ? (count / totalRecords) * 100 : 0;
            const approvalRate = ToNumber(x.approvalRate);

            html += `
            <tr>
                <td class="strong">${x.name}</td>
                <td class="num">${FormatN(count)}</td>
                <td>
                    <div class="prog">
                        <div class="track">
                            <div class="fill" style="width:${share.toFixed(1)}%;background:${C.navy};"></div>
                        </div>
                        <span class="muted">${share.toFixed(1)}%</span>
                    </div>
                </td>
                <td class="num">${approvalRate.toFixed(1)}%</td>
            </tr>
        `;
        });

        $tbody.html(html);
    };

    const LoadStrategicPortfolio = (filters) => {
        const effectiveFilters = BuildEffectiveFilters(filters);

        $.ajax({
            url: API_URL,
            type: "GET",
            cache: false,
            data: GetPayload(effectiveFilters),
            success: (response) => {
                const totalRecords =
                    response?.totalRecords ??
                    response?.TotalRecords ??
                    0;

                const priorities = NormalizeItems(
                    response?.priority ??
                    response?.Priority
                );

                const capabilities = NormalizeItems(
                    response?.capability ??
                    response?.Capability
                );

                const capabilityPriority =
                    response?.capabilityPriority ??
                    response?.CapabilityPriority ??
                    [];

                SetScopeCount(totalRecords);
                RenderPriorityMix(priorities);
                RenderCapabilityPriority(capabilityPriority);
                RenderCapabilitySummary(capabilities, totalRecords);
            },
            error: (xhr) => {
                console.error("Failed to load Strategic Portfolio", xhr);

                $("#capabilitySummaryBody").html(`
                    <tr>
                        <td colspan="4">
                            Unable to load data
                        </td>
                    </tr>
                `);
            }
        });
    };

    const Attach_Filter_Events = () => {
        $(document)
            .off("commonFilterChanged.portfolio")
            .on("commonFilterChanged.portfolio", (_e, filters) => {
                if (loadTimer) clearTimeout(loadTimer);
                loadTimer = setTimeout(() => {
                    LoadStrategicPortfolio(filters || {});
                }, 250);
            });

        $(document)
            .off("forecastConfigApplied.portfolio")
            .on("forecastConfigApplied.portfolio", (_e, weights) => {
                const base = window.CommonFilters ? window.CommonFilters.getValues() : {};
                LoadStrategicPortfolio({ ...base, ...(weights || {}) });
            });
    };

    const Init_Portfolio = () => {
        if (!window.CommonFilters && typeof Attach_Common_Events === "function") {
            Attach_Common_Events();
        } else if (!window.CommonFilters && typeof attach_common_events === "function") {
            attach_common_events();
        }

        const filters =
            window.CommonFilters
                ? window.CommonFilters.getValues()
                : {};

        LoadStrategicPortfolio(filters);
        Attach_Filter_Events();
    };

    Init_Portfolio();
};