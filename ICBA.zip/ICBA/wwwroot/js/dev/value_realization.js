﻿$(document).ready(() => Attach_ValueRealization_Events());

const Attach_ValueRealization_Events = () => {
    const API_URL = "ValueRealization?handler=ValueRealizationData";

    const C = {
        navy: "#002677",
        navy2: "#2f52a0",
        orange: "#e38a6e",
        gold: "#f0a202"
    };

    let capChart = null;
    let splitChart = null;
    let loadTimer = null;

    const ToNumber = (v) => Number.isNaN(Number(v)) ? 0 : Number(v);

    const FormatMoney = (n) => {
        const v = ToNumber(n);
        const a = Math.abs(v);
        const sign = v < 0 ? "-" : "";
        if (a >= 1e9) return `${sign}$${(a / 1e9).toFixed(2)}Bn`;
        if (a >= 1e6) return `${sign}$${(a / 1e6).toFixed(2)}Mn`;
        if (a >= 1e3) return `${sign}$${(a / 1e3).toFixed(0)}K`;
        return `${sign}$${Math.round(a).toLocaleString("en-US")}`;
    };

    const DestroyChart = (chartRef) => {
        if (chartRef) chartRef.destroy();
    };

    const SetScopeCount = (count) => {
        if (window.CommonFilters && typeof window.CommonFilters.setScopeCount === "function") {
            window.CommonFilters.setScopeCount(ToNumber(count));
        }
    };

    const GetPayload = (filters) => ({
        capability: filters?.capability || "",
        business: filters?.business || "",
        geo: filters?.geo || "",
        priority: filters?.priority || "",
        stage: filters?.stage || "",
        timeType: filters?.timeType || "all",
        year: filters?.year || "",
        start: filters?.start || "",
        end: filters?.end || "",

        // kept for parity with Leadership Cockpit forecast payload
        inApproval: filters?.inApproval ?? 10,
        approvedNoOwner: filters?.approvedNoOwner ?? 25,
        approvedWithPlan: filters?.approvedWithPlan ?? 50,
        inImplementation: filters?.inImplementation ?? 75,
        implementedNotValidated: filters?.implementedNotValidated ?? 90,
        validated: filters?.validated ?? 100
    });

    const BuildEffectiveFilters = (filters) => {
        const globalFilters = window.CommonFilters && typeof window.CommonFilters.getValues === "function"
            ? window.CommonFilters.getValues()
            : {};

        const directWeights = {
            inApproval: filters?.inApproval,
            approvedNoOwner: filters?.approvedNoOwner,
            approvedWithPlan: filters?.approvedWithPlan,
            inImplementation: filters?.inImplementation,
            implementedNotValidated: filters?.implementedNotValidated,
            validated: filters?.validated
        };

        return {
            ...globalFilters,
            ...(filters || {}),
            ...Object.fromEntries(Object.entries(directWeights).filter(([, v]) => v !== undefined && v !== null))
        };
    };

    const FormatCompact = (n) => {
        const v = ToNumber(n);
        const a = Math.abs(v);
        if (a >= 1e9) return `${(v / 1e9).toFixed(1)}B`;
        if (a >= 1e6) return `${(v / 1e6).toFixed(1)}M`;
        if (a >= 1e3) return `${(v / 1e3).toFixed(1)}K`;
        return Math.round(v).toLocaleString("en-US");
    };

    const RenderCards = (kpis, stageValue) => {
        $("#vxHard").text(FormatCompact(kpis?.hard ?? 0));
        $("#vxSoft").text(FormatCompact(kpis?.soft ?? 0));
        $("#vxWeighted").text(FormatCompact(kpis?.weightedPipeline ?? 0));
        $("#vxForecast").text(FormatCompact(kpis?.forecast ?? 0));

        $("#vxSubmitted").text(FormatMoney(stageValue?.submitted ?? 0));
        $("#vxPendingApproval").text(FormatMoney(stageValue?.pendingApproval ?? 0));
        $("#vxApprovedImplemented").text(FormatMoney(stageValue?.approvedImplemented ?? 0));
        $("#vxApprovedNotImpl").text(FormatMoney(stageValue?.approvedNotImplemented ?? 0));
    };

    const RenderCapabilityChart = (items) => {
        const canvas = document.getElementById("vxCap");
        if (!canvas) return;
        DestroyChart(capChart);

        const labels = (items || []).map(x => x.name);
        const hard = (items || []).map(x => ToNumber(x.hard));
        const soft = (items || []).map(x => ToNumber(x.soft));

        capChart = new Chart(canvas, {
            type: "bar",
            data: {
                labels,
                datasets: [
                    { label: "Hard", data: hard, backgroundColor: C.navy, borderRadius: 3, maxBarThickness: 22 },
                    { label: "Soft", data: soft, backgroundColor: C.orange, borderRadius: 3, maxBarThickness: 22 }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: "y",
                plugins: { legend: { position: "bottom" } },
                scales: {
                    x: { stacked: true, beginAtZero: true },
                    y: { stacked: true, grid: { display: false } }
                }
            }
        });
    };

    const DoughnutPercentPlugin = {
        id: "doughnutPercentLabels",
        afterDatasetsDraw: (chart) => {
            const dataset = chart?.data?.datasets?.[0];
            if (!dataset) return;

            const raw = (dataset.data || []).map(ToNumber);
            const visibleData = raw.map((v, i) => (chart.getDataVisibility(i) ? v : 0));
            const total = visibleData.reduce((sum, v) => sum + v, 0);
            if (!total) return;

            const meta = chart.getDatasetMeta(0);
            const { ctx } = chart;

            ctx.save();
            ctx.fillStyle = "#ffffff";
            ctx.font = "600 11px Segoe UI";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";

            meta.data.forEach((arc, i) => {
                if (!chart.getDataVisibility(i)) return;

                const val = visibleData[i];
                if (val <= 0) return;

                const pct = (val / total) * 100;
                if (pct < 4) return;

                const { x, y } = arc.tooltipPosition();
                ctx.fillText(`${pct.toFixed(1)}%`, x, y);
            });

            ctx.restore();
        }
    };

    const RenderSplitChart = (kpis) => {
        const canvas = document.getElementById("vxSplit");
        if (!canvas) return;
        DestroyChart(splitChart);

        splitChart = new Chart(canvas, {
            type: "doughnut",
            data: {
                labels: ["Realized hard", "Realized soft", "Pipeline hard", "Pipeline soft"],
                datasets: [{
                    data: [
                        ToNumber(kpis?.hard),
                        ToNumber(kpis?.soft),
                        ToNumber(kpis?.pipelineHard),
                        ToNumber(kpis?.pipelineSoft)
                    ],
                    backgroundColor: [C.navy, C.navy2, C.orange, C.gold],
                    borderWidth: 0
                }]
            },
            plugins: [DoughnutPercentPlugin],
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: "60%",
                plugins: {
                    legend: {
                        position: "bottom",
                        labels: {
                            usePointStyle: true,
                            pointStyle: "circle",
                            boxWidth: 10,
                            boxHeight: 10
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => {
                                const val = ToNumber(ctx.raw);
                                const total = (ctx.dataset.data || []).reduce((s, v, i) => {
                                    return s + (ctx.chart.getDataVisibility(i) ? ToNumber(v) : 0);
                                }, 0);

                                const pct = total ? ((val / total) * 100).toFixed(1) : "0.0";
                                return `${ctx.label}: ${val.toLocaleString("en-US")} (${pct}%)`;
                            }
                        }
                    }
                }
            }
        });
    };

    const LoadValueRealization = (filters) => {
        const effectiveFilters = BuildEffectiveFilters(filters);

        $.ajax({
            url: API_URL,
            type: "GET",
            cache: false,
            data: GetPayload(effectiveFilters),
            success: (response) => {
                SetScopeCount(response?.totalRecords ?? 0);
                RenderCards(response?.kpis ?? {}, response?.stageValue ?? {});
                RenderCapabilityChart(response?.capabilityValue ?? []);
                RenderSplitChart(response?.kpis ?? {});
            },
            error: (xhr) => {
                console.error("Failed to load Value Realization data", xhr);
                SetScopeCount(0);
                RenderCards({}, {});
                RenderCapabilityChart([]);
                RenderSplitChart({});
            }
        });
    };

    const Attach_Filter_Events = () => {
        $(document)
            .off("commonFilterChanged.value")
            .on("commonFilterChanged.value", (_e, filters) => {
                if (loadTimer) clearTimeout(loadTimer);
                loadTimer = setTimeout(() => {
                    LoadValueRealization(filters || {});
                }, 250);
            });

        $(document)
            .off("forecastConfigApplied.value")
            .on("forecastConfigApplied.value", (_e, weights) => {
                const base = window.CommonFilters ? window.CommonFilters.getValues() : {};
                LoadValueRealization({ ...base, ...(weights || {}) });
            });
    };

    const Init_ValueRealization = () => {
        if (!window.CommonFilters && typeof Attach_Common_Events === "function") {
            Attach_Common_Events();
        } else if (!window.CommonFilters && typeof attach_common_events === "function") {
            attach_common_events();
        }

        const filters = window.CommonFilters ? window.CommonFilters.getValues() : {};
        LoadValueRealization(filters);
        Attach_Filter_Events();
    };

    Init_ValueRealization();
};