﻿using Constants;
using Extensions;
//using ICBA.Models;
//using ICBA.Models.ViewModel;
using ICBA;
using ICBA.Constants;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Caching.Memory;
using Services;
using System.Collections.Generic;
using System.Linq;

namespace ICBA.PlatformAbstracts;

[IgnoreAntiforgeryToken]
public abstract class PageModelBase : PageModel
{
    protected readonly IWebHostEnvironment _environment;
    protected readonly DIServiceInterface _serviceInterface;
    public bool IsAdmin;
    public string UserName;
    public string UserMSID;
    public string LoggedInUserMSId => User?.Claims?.FirstOrDefault(c =>
         c.Type.Equals("samaccountname", StringComparison.OrdinalIgnoreCase) ||
         c.Type.Equals("preferred_username", StringComparison.OrdinalIgnoreCase) ||
         c.Type.Equals("upn", StringComparison.OrdinalIgnoreCase) ||
         c.Type.Equals("email", StringComparison.OrdinalIgnoreCase))
     ?.Value ?? "";
    public PageModelBase(DIServiceInterface serviceInterface, IWebHostEnvironment environment)
    {
        _serviceInterface = serviceInterface;
        _environment = environment;
    }

    public override void OnPageHandlerExecuting(PageHandlerExecutingContext context)
    {
        GetUserName();
        var usr = User?.Claims?.FirstOrDefault(c => c.Type.ToLower() == "samaccountname")?.Value;
        var role = GetLoginRole();
        if (role == UserRoles.UNAUTHORIZED)
        {
            context.Result = new RedirectToPageResult("/Unauthorized");
        }

        IsAdmin = role == UserRoles.DEV;


    }

    protected string GetLoginMSId() => User.Claims.FirstOrDefault(c => c.Type.ToLower() == "samaccountname")!.Value;
    protected string GetLoginDisplayName() => User.Claims.FirstOrDefault(c => c.Type == "displayName")!.Value;
    private static void RedirectToHome(PageHandlerExecutingContext context)
    {
        context.Result = new RedirectToPageResult("Index");
    }

    private static void RedirectToNotAuthorize(PageHandlerExecutingContext context)
    {
        context.Result = new RedirectToPageResult("Unauthorized");
        //context.Result = new UnauthorizedResult();
    }

    public override void OnPageHandlerExecuted(PageHandlerExecutedContext context)
    {
        base.OnPageHandlerExecuted(context);
    }
    public void GetUserName()
    {
        UserMSID = User.Claims.FirstOrDefault(c => c.Type.ToLower() == "samaccountname")?.Value!;
        try
        {
            UserName = User.Claims.FirstOrDefault(c => c.Type == "displayName")?.Value ?? UserMSID;
        }
        catch (Exception)
        {
            UserName = UserMSID;
        }
    }

    protected UserRoles GetLoginRole()
    {
        if (Array.Exists(new string[] { "sbandi32" }, x => x == LoggedInUserMSId.ToLower())) return UserRoles.DEV;

        var rolesClaim = User.Claims.ToList().FindAll(x => x.Type == "groups");

        switch (true)
        {
            case var _ when (rolesClaim is null || rolesClaim.Count == 0):
                return UserRoles.UNAUTHORIZED;
            case var _ when (rolesClaim.Exists(x => x.Value.ToLower().Contains("azu_voyager_icba_user"))):
                return UserRoles.USER;
            case var _ when (rolesClaim.Exists(x => x.Value.ToLower().Contains("azu_voyager_icba_dev"))):
                return UserRoles.DEV;
            case var _ when (rolesClaim.Exists(x => x.Value.ToLower().Contains("azu_voyager_icba_admin"))):
                return UserRoles.ADMIN;
            default:
                return UserRoles.UNAUTHORIZED;
        }
    }


}
