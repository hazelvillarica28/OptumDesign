using Extensions;
using ICBA.Services;
using Services;
using Services.CacheService;
using ICServices.CacheService;


var builder = WebApplication.CreateBuilder(args);

IWebHostEnvironment environment = builder.Environment;

/* ======================================================
   BASIC SERVICES
====================================================== */

builder.Services.AddMemoryCachePolicy();
builder.Services.AddSessionPolicy(environment);
builder.Services.AddCookiePolicy(environment);
builder.Services.AddHttpPolicy();
builder.Services.AddIDSContract();

builder.Services.AddRazorPages();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddTransient<DIServiceInterface>();

builder.Services.AddMemoryCache();
builder.Services.AddScoped<IBrightIdeaCacheService, BrightIdeaCacheService>();
//builder.Services.AddHostedService<CacheWarmupService>();

/* ======================================================
   OIDC AUTHENTICATION
====================================================== */

builder.Services.AddOIDCAuthenticationPolicy(environment, builder.Configuration);
builder.Services.AddAuthorizationPolicy();


builder.WebHost.ConfigureKestrel(serverOptions =>
{
    serverOptions.Limits.MaxRequestHeaderCount = 8192;
    serverOptions.Limits.MaxRequestHeadersTotalSize = 32 * 1024;
});

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseStatusCodePages();
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseCookiePolicy();
app.UseAuthentication();
app.UseAuthorization();
app.UseSession();

app.MapRazorPages();

app.Run();