﻿using System.Data;
using Microsoft.Data.SqlClient;

namespace ICBA.Services.DataServices.Abstract
{
    public class DataServiceConfiguration
    {
        private IConfiguration _configurations;
        private string _connectionString = "";

        internal DataServiceConfiguration(IConfiguration configurations)
        {
            _configurations = configurations;
            _connectionString = _configurations.GetConnectionString("Default");
        }

        internal SqlConnection GetConnection() => new SqlConnection(_connectionString);

        internal SqlCommand GetCommand(string query, SqlConnection conn)
        {
            var command = new SqlCommand(query, conn);
            command.CommandType = CommandType.StoredProcedure;
            return command;
        }

        internal SqlCommand GetCommand(string query)
        {
            var command = new SqlCommand(query, new SqlConnection(_connectionString));
            command.CommandType = CommandType.StoredProcedure;
            return command;
        }

        // NEW: direct SQL (views / raw select)
        internal SqlCommand GetTextCommand(string query)
        {
            var command = new SqlCommand(query, new SqlConnection(_connectionString));
            command.CommandType = CommandType.Text;
            return command;
        }

        internal async Task<int> ExecuteNonQueryAsync(SqlCommand command, SqlConnection con)
        {
            int? rdr;
            try
            {
                await con.OpenAsync();
                rdr = await command.ExecuteNonQueryAsync();
            }
            catch (Exception ex)
            {
                string str = ex.Message;
                throw;
            }
            con.Close();
            return rdr ?? 0;
        }
    }
}