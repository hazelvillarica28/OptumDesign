﻿using Microsoft.Extensions.Caching.Memory;
using Services.DataService;

namespace Services
{
    public class DIServiceInterface
    {
        public IMemoryCache Cache;
        public IConfiguration Configuration;
        public CoreDataContext CoreDataContext;

        public DIServiceInterface(IMemoryCache cache, IConfiguration configuration,
               CoreDataContext coreDataContext)
        {
            Configuration = configuration;
            Cache = cache;
            CoreDataContext = coreDataContext;
        }
    }
}
