﻿using ICBA.Models;
using Microsoft.Extensions.Caching.Memory;
using Services.DataService;
using System.Diagnostics;

namespace Services.CacheService
{
    public class BrightIdeaCacheService : IBrightIdeaCacheService
    {
        private readonly CoreDataContext _coreDataContext;
        private readonly IMemoryCache _cache;

        private const string CacheKey = "BrightIdeaDumpBaseData";

        public BrightIdeaCacheService(
            CoreDataContext coreDataContext,
            IMemoryCache cache)
        {
            _coreDataContext = coreDataContext;
            _cache = cache;
        }

        public async Task<List<BrightIdeaDumpReportViewModel>> GetBaseDataAsync()
        {
            Console.WriteLine("GetBaseDataAsync Called");

            if (_cache.TryGetValue(CacheKey,
                out List<BrightIdeaDumpReportViewModel>? cached)
                && cached != null)
            {
                Console.WriteLine("CACHE HIT");
                return cached;
            }

            Console.WriteLine("CACHE MISS");

            var sw = Stopwatch.StartNew();

            var data =
                await _coreDataContext.GetBrightIdeaDumpBaseDataAsync();

            sw.Stop();

            Console.WriteLine($"Rows={data.Count}");
            Console.WriteLine($"Load={sw.ElapsedMilliseconds}ms");

            _cache.Set(CacheKey, data,
                new MemoryCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow =
                        TimeSpan.FromMinutes(10),
                    SlidingExpiration =
                        TimeSpan.FromMinutes(5)
                });

            return data;
        }
    }
}