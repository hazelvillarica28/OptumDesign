﻿using ICBA.Models;

namespace Services.CacheService
{
    public interface IBrightIdeaCacheService
    {
        Task<List<BrightIdeaDumpReportViewModel>> GetBaseDataAsync();
    }
}