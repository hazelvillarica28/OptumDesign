﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Services.CacheService;

namespace ICServices.CacheService;

public class CacheWarmupService : BackgroundService
{
    private readonly IServiceProvider _serviceProvider;

    public CacheWarmupService(IServiceProvider serviceProvider)
    {
        Console.WriteLine("CacheWarmupService Created");
        _serviceProvider = serviceProvider;
    }

    protected override async Task ExecuteAsync(
     CancellationToken stoppingToken)
    {
        Console.WriteLine("Warmup Started");

        try
        {
            using var scope = _serviceProvider.CreateScope();

            Console.WriteLine("Scope Created");

            var service = scope.ServiceProvider
                .GetRequiredService<IBrightIdeaCacheService>();

            Console.WriteLine("Service Resolved");

            await service.GetBaseDataAsync();

            Console.WriteLine("Warmup Finished");
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.ToString());
        }
    }
}