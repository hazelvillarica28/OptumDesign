﻿using Microsoft.AspNetCore.Builder;

namespace Extensions;

public static class ConfigureAppUsage
{
    public static IApplicationBuilder AddEndPoints(this IApplicationBuilder builder)
    {
        return builder.UseEndpoints(endpoints =>
        {
            endpoints.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");
            endpoints.MapControllerRoute(
              name: "areas",
              pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}"
            );
            endpoints.MapControllers();
        });

    }
}

