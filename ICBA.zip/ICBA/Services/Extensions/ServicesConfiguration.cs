﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Server.IISIntegration;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Services.DataService;

//using Services.DataService;
using System.Runtime.CompilerServices;
//using RCMCodingConfiguration;

namespace Extensions;

public static class ServicesConfiguration
{
    public static void AddIDSContract(this IServiceCollection services)
    {
        services.AddScoped<CoreDataContext>();
        //services.AddScoped<QuizDataContext>();
        //services.AddScoped<AuthorDataContext>();
        //services.AddScoped<IDSContract<Module>, ModuleContext>();
    }
    public static void AddVCPath(this IServiceCollection services)
    {
        /*{2} area ,{1} controller, {0} action component path "components/{viewcomponentname}/{viewcomponentviewname} is in action {0} */
        services.Configure<RazorViewEngineOptions>(o =>
        { o.ViewLocationFormats.Add("/{0}" + RazorViewEngine.ViewExtension); });
    }

    public static void AddCookiePolicy(this IServiceCollection services, IWebHostEnvironment environment) =>
        services.Configure<CookiePolicyOptions>("CookiePolicy", options =>
        {
            options.CheckConsentNeeded = context => true;
            options.MinimumSameSitePolicy = SameSiteMode.Strict;
            options.ConsentCookie.HttpOnly = true;
            options.ConsentCookie.IsEssential = true;
            options.HttpOnly = Microsoft.AspNetCore.CookiePolicy.HttpOnlyPolicy.None;
        });

    public static void AddSessionPolicy(this IServiceCollection services, IWebHostEnvironment environment) => services.AddSession(options =>
    {
        options.IdleTimeout = TimeSpan.FromMinutes(20);
        options.Cookie.HttpOnly = true;
        options.Cookie.IsEssential = true;
        //options.Cookie.SameSite = SameSiteMode.Lax;  
        options.Cookie.Name = "RCMCodingCookies";
    });


    public static void AddAuthenticationPolicy(this IServiceCollection services)
    {
        services.AddAuthentication(IISDefaults.AuthenticationScheme);
        //builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme).AddNegotiate();
    }

    public static void AddOIDCAuthenticationPolicy(this IServiceCollection services, IWebHostEnvironment environment, ConfigurationManager configuration)
    {
        var oidc = configuration.GetSection("AzureAuth");
        var clientId = oidc["ClientId"];
        var clientSecret = oidc["ClientSecret"];
        var authority = oidc["Authority"];

        //string[]? scope = configuration.GetSection("OIDC:Scope").Get<string[]>();

        if (clientId == null || clientSecret == null || authority == null)
        {
            throw new InvalidOperationException("Authentication configuration not found");
        }

        services.AddAuthentication(options =>
        {
            options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
        }).AddCookie().AddOpenIdConnect(options =>
        {
            options.ClientId = configuration.GetValue<string>("AzureAuth:ClientID");
            options.ClientSecret = configuration.GetValue<string>("AzureAuth:ClientSecret");
            options.ResponseType = "code";
            options.CallbackPath = "/signin-oidc";
            options.Authority = configuration.GetValue<string>("AzureAuth:Authority");
            options.SaveTokens = false;
            options.Scope.Add("profile");
            options.Scope.Add("email");
            options.Scope.Add("openid");
        });
    }


    public static void AddAuthorizationPolicy(this IServiceCollection services) => services.AddAuthorization(options =>
    {
        options.FallbackPolicy = options.DefaultPolicy;
    });

    public static void AddMemoryCachePolicy(this IServiceCollection services)
    {
        services.AddDistributedMemoryCache();
        services.AddOptions();
    }


    public static void AddHttpPolicy(this IServiceCollection services)
    {
        services.AddHttpContextAccessor();
        services.AddHttpClient();
    }
    public static void AddCorsConfig(this IServiceCollection services)
    {
        services.AddCors(options =>
        {
            options.AddPolicy(name: "myoriginpolicy",
                          builder =>
                          {
                              builder.WithOrigins("http://example.com",
                                                  "https://localhost:44305/");
                          });
        });
    }
}

