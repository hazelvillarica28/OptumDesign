﻿using ICBA.Models;

namespace ICBA.Services;

public sealed record PipelineWeightConfig(
    decimal InApproval = 0.10m,
    decimal ApprovedNoOwner = 0.25m,
    decimal ApprovedWithPlan = 0.50m,
    decimal InImplementation = 0.75m,
    decimal ImplementedNotValidated = 0.90m,
    decimal Validated = 1.00m);

public static class PipelineForecastLogic
{
    public static PipelineWeightConfig FromPercent(
        int? inApproval, int? approvedNoOwner, int? approvedWithPlan,
        int? inImplementation, int? implementedNotValidated, int? validated)
        => new(
            (inApproval ?? 10) / 100m,
            (approvedNoOwner ?? 25) / 100m,
            (approvedWithPlan ?? 50) / 100m,
            (inImplementation ?? 75) / 100m,
            (implementedNotValidated ?? 90) / 100m,
            (validated ?? 100) / 100m);

    public static decimal WeightedPipeline(IEnumerable<BrightIdeaDumpReportViewModel> rows, PipelineWeightConfig w)
        => rows.Sum(r =>
        {
            var bucket = ClassifyPipelineBucket(r);
            if (bucket is null) return 0m;

            var baseValue = r.ExpectedHard + r.ExpectedSoft;
            var weight = bucket switch
            {
                "inApproval" => w.InApproval,
                "approvedNoOwner" => w.ApprovedNoOwner,
                "approvedWithPlan" => w.ApprovedWithPlan,
                "inImplementation" => w.InImplementation,
                "implementedNotValidated" => w.ImplementedNotValidated,
                "validated" => w.Validated,
                _ => 0m
            };

            return baseValue * weight;
        });

    private static string? ClassifyPipelineBucket(BrightIdeaDumpReportViewModel r)
    {
        var validated = (r.IdeaValidated ?? string.Empty).ToLowerInvariant();
        var hasOwner = !string.IsNullOrWhiteSpace(r.AmbassadorName) && r.AmbassadorName != "-";
        var hasPlan = r.ProposedImplDate.HasValue;

        if (string.Equals(r.FunnelStage, "In Approval", StringComparison.OrdinalIgnoreCase)) return "inApproval";
        if (string.Equals(r.FunnelStage, "Approved", StringComparison.OrdinalIgnoreCase) && !hasOwner) return "approvedNoOwner";
        if (string.Equals(r.FunnelStage, "Approved", StringComparison.OrdinalIgnoreCase) && (hasOwner || hasPlan)) return "approvedWithPlan";
        if (string.Equals(r.FunnelStage, "In Implementation", StringComparison.OrdinalIgnoreCase)) return "inImplementation";
        if (string.Equals(r.FunnelStage, "Implemented", StringComparison.OrdinalIgnoreCase) && validated.Contains("not")) return "implementedNotValidated";
        if (string.Equals(r.FunnelStage, "Implemented", StringComparison.OrdinalIgnoreCase) && validated.Contains("validated")) return "validated";
        return null;
    }
}