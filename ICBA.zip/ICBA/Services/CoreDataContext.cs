﻿using Constants;
using ICBA.Models;
using ICBA.Services.DataServices.Abstract;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Services.DataService;

public class CoreDataContext : DataServiceConfiguration
{
    private readonly IMemoryCache _cache;
    private const string DataConfidenceCacheKey = "GetDataConfidenceList";

    public CoreDataContext(IConfiguration configurations, IMemoryCache cache) : base(configurations)
    {
        _cache = cache;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static string? ReadString(SqlDataReader reader, int ordinal)
    => reader.IsDBNull(ordinal)
        ? null
        : Convert.ToString(reader.GetValue(ordinal));

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static decimal ReadDecimal(SqlDataReader reader, int ordinal)
        => reader.IsDBNull(ordinal)
            ? 0m
            : reader.GetDecimal(ordinal);

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static DateTime? ReadDateTime(SqlDataReader reader, int ordinal)
        => reader.IsDBNull(ordinal)
            ? null
            : reader.GetDateTime(ordinal);
    
    public async Task<List<BrightIdeaDumpReportViewModel>> GetBrightIdeaDumpBaseDataAsync()
    {
        var list = new List<BrightIdeaDumpReportViewModel>(4096);

        var sql = $@"
        SELECT
            IdeaID,
            IdeaTitle,

            CreatedOn,
            ModifiedOn,

            EmployeeID,
            FunctionName,

            Capability,
            BusinessName,
            Geographies,
            PriorityCategory,

            FunnelStage,
            Stage_Name,

            ThemeName,
            SubThemeName,

            ProblemStatement,
            Recommendation,

            AmbassadorName,
            MasterAmbassadorName,

            IdeaValidated,
            ProposedImplDate,

            PotentialSavings,
            ExpectedHard,
            ExpectedSoft,

            RealizedHardSavings,
            RealizedSoftSavings,

            [AIRB Status] AS AIRBStatus,
            [Is AI] AS IsAI,
            IdeaType

        FROM {SPQueryKeys.VW_GetReportBrightIdeaDump}";

        await using var command = GetTextCommand(sql);
        command.CommandTimeout = 180;

        await using var con = command.Connection;

        var sw = Stopwatch.StartNew();

        await con.OpenAsync();

        await using var rdr = await command.ExecuteReaderAsync();

        var oIdeaId = rdr.GetOrdinal("IdeaID");
        var oIdeaTitle = rdr.GetOrdinal("IdeaTitle");
        var oCreatedOn = rdr.GetOrdinal("CreatedOn");
        var oModifiedOn = rdr.GetOrdinal("ModifiedOn");
        var oEmployeeId = rdr.GetOrdinal("EmployeeID");
        var oFunctionName = rdr.GetOrdinal("FunctionName");
        var oCapability = rdr.GetOrdinal("Capability");
        var oBusinessName = rdr.GetOrdinal("BusinessName");
        var oGeographies = rdr.GetOrdinal("Geographies");
        var oPriorities = rdr.GetOrdinal("PriorityCategory");
        var oFunnelStage = rdr.GetOrdinal("FunnelStage");
        var oStageName = rdr.GetOrdinal("Stage_Name");
        var oThemeName = rdr.GetOrdinal("ThemeName");
        var oSubThemeName = rdr.GetOrdinal("SubThemeName");
        var oProblemStatement = rdr.GetOrdinal("ProblemStatement");
        var oRecommendation = rdr.GetOrdinal("Recommendation");
        var oAmbassadorName = rdr.GetOrdinal("AmbassadorName");
        var oMasterAmbassadorName = rdr.GetOrdinal("MasterAmbassadorName");
        var oIdeaValidated = rdr.GetOrdinal("IdeaValidated");
        var oProposedImplDate = rdr.GetOrdinal("ProposedImplDate");
        var oPotentialSavings = rdr.GetOrdinal("PotentialSavings");
        var oExpectedHard = rdr.GetOrdinal("ExpectedHard");
        var oExpectedSoft = rdr.GetOrdinal("ExpectedSoft");
        var oRealizedHardSavings = rdr.GetOrdinal("RealizedHardSavings");
        var oRealizedSoftSavings = rdr.GetOrdinal("RealizedSoftSavings");
        var oAirbStatus = rdr.GetOrdinal("AIRBStatus");
        var oIsAi = rdr.GetOrdinal("IsAI");
        var oIdeaType = rdr.GetOrdinal("IdeaType");

        while (await rdr.ReadAsync())
        {
            list.Add(new BrightIdeaDumpReportViewModel
            {
                IdeaID = ReadString(rdr, oIdeaId),
                IdeaTitle = ReadString(rdr, oIdeaTitle),

                CreatedOn = ReadDateTime(rdr, oCreatedOn),
                ModifiedOn = ReadDateTime(rdr, oModifiedOn),

                EmployeeID = ReadString(rdr, oEmployeeId),
                FunctionName = ReadString(rdr, oFunctionName),

                Capability = ReadString(rdr, oCapability),
                BusinessName = ReadString(rdr, oBusinessName),
                Geographies = ReadString(rdr, oGeographies),
                Priorities = ReadString(rdr, oPriorities),

                FunnelStage = ReadString(rdr, oFunnelStage),
                StageName = ReadString(rdr, oStageName),

                ThemeName = ReadString(rdr, oThemeName),
                SubThemeName = ReadString(rdr, oSubThemeName),

                ProblemStatement = ReadString(rdr, oProblemStatement),
                Recommendation = ReadString(rdr, oRecommendation),

                AmbassadorName = ReadString(rdr, oAmbassadorName),
                MasterAmbassadorName = ReadString(rdr, oMasterAmbassadorName),

                IdeaValidated = ReadString(rdr, oIdeaValidated),
                ProposedImplDate = ReadDateTime(rdr, oProposedImplDate),

                PotentialSavings = ReadDecimal(rdr, oPotentialSavings),
                ExpectedHard = ReadDecimal(rdr, oExpectedHard),
                ExpectedSoft = ReadDecimal(rdr, oExpectedSoft),

                RealizedHardSavings = ReadDecimal(rdr, oRealizedHardSavings),
                RealizedSoftSavings = ReadDecimal(rdr, oRealizedSoftSavings),

                AIRBStatus = ReadString(rdr, oAirbStatus),
                IsAI = ReadString(rdr, oIsAi),
                IdeaType = ReadString(rdr, oIdeaType)
            });
        }
        return list;
    }

}