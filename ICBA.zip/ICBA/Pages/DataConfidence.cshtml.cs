﻿using ICBA.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Caching.Memory;
using Services.CacheService;
using Services.DataService;

namespace ICBA.Pages
{
    public class DataConfidenceModel : PageModel
    {
        private readonly IBrightIdeaCacheService _baseDataService;
        private readonly IMemoryCache _cache;

        public DataConfidenceModel(IBrightIdeaCacheService baseDataService, IMemoryCache cache)
        {
            _baseDataService = baseDataService;
            _cache = cache;
        }

        public DateTime AsOfDate { get; set; }
        public int TotalRecords { get; set; }
        public List<BrightIdeaDumpReportViewModel> BrightIdeaDumpReportList { get; set; } = new();

        public async Task OnGetAsync()
        {
            var data = await _baseDataService.GetBaseDataAsync();
            BrightIdeaDumpReportList = data;
            TotalRecords = data.Count;
            AsOfDate = DateTime.Today;
        }

        private static bool EqualsFilter(string? source, string? filter)
        {
            if (string.IsNullOrWhiteSpace(filter))
                return true;

            return string.Equals(
                source?.Trim(),
                filter.Trim(),
                StringComparison.OrdinalIgnoreCase);
        }

        public async Task<IActionResult> OnGetDataConfidenceDataAsync(
            string? capability,
            string? business,
            string? geo,
            string? priority,
            string? stage,
            string? timeType,
            string? year,
            string? start,
            string? end)
        {
            var responseCacheKey = $"dc:v2:{capability}:{business}:{geo}:{priority}:{stage}:{timeType}:{year}:{start}:{end}";

            if (_cache.TryGetValue(responseCacheKey, out object? cached) && cached is not null)
                return new JsonResult(cached);

            var data = await _baseDataService.GetBaseDataAsync();
            var query = data.AsEnumerable();

            query = query.Where(x =>
                EqualsFilter(x.Capability, capability) &&
                EqualsFilter(x.BusinessName, business) &&
                EqualsFilter(x.Geographies, geo) &&
                EqualsFilter(x.Priorities, priority) &&
                EqualsFilter(x.FunnelStage, stage));

            if (string.Equals(timeType, "year", StringComparison.OrdinalIgnoreCase) && int.TryParse(year, out var y))
            {
                query = query.Where(x => x.CreatedOn.HasValue && x.CreatedOn.Value.Year == y);
            }
            else if (string.Equals(timeType, "range", StringComparison.OrdinalIgnoreCase))
            {
                DateTime? s = DateTime.TryParse(start, out var sv) ? sv.Date : null;
                DateTime? e = DateTime.TryParse(end, out var ev) ? ev.Date.AddDays(1).AddTicks(-1) : null;

                query = query.Where(x =>
                    x.CreatedOn.HasValue &&
                    (!s.HasValue || x.CreatedOn.Value >= s.Value) &&
                    (!e.HasValue || x.CreatedOn.Value <= e.Value));
            }

            var rows = query.ToList();
            var total = rows.Count == 0 ? 1 : rows.Count;

            static bool Missing(string? v) => string.IsNullOrWhiteSpace(v) || v.Trim() == "-";

            static bool IsImplementedLike(BrightIdeaDumpReportViewModel x)
            {
                if (string.Equals(x.FunnelStage?.Trim(), "Implemented", StringComparison.OrdinalIgnoreCase))
                    return true;

                return (x.StageName ?? string.Empty).IndexOf("implemented", StringComparison.OrdinalIgnoreCase) >= 0;
            }

            var checks = new[]
            {
                new { name = "Missing theme", count = rows.Count(x => Missing(x.ThemeName)) },
                new { name = "Missing capability", count = rows.Count(x => Missing(x.Capability)) },
                new { name = "Missing ambassador / owner", count = rows.Count(x => Missing(x.AmbassadorName)) },
                new { name = "Missing proposed implementation date", count = rows.Count(x => !x.ProposedImplDate.HasValue) },
                new { name = "Implemented without validated savings", count = rows.Count(x =>
                    IsImplementedLike(x) &&
                    (x.IdeaValidated ?? string.Empty).ToLowerInvariant().Contains("not")) }
            }
            .Select(x => new
            {
                x.name,
                x.count,
                rate = Math.Round((decimal)x.count / total, 4)
            })
            .ToList();

            var readiness = new[]
            {
                new { name = "Idea volume & approval rate", desc = "Available and reliable", status = "Reliable" },
                new { name = "Approval backlog & decision age", desc = "Available with proxy (Created→Modified)", status = "Proxy" },
                new { name = "Full approval turnaround & cycle time", desc = "Requires stage-transition timestamps", status = "Needs field" },
                new { name = "Ideas per 100 employees / participation %", desc = "Requires eligible-employee denominator", status = "Needs field" },
                new { name = "Validated savings confidence", desc = "Requires validation-status field", status = "Proxy" },
                new { name = "Executive-sponsored / adoption / AI-readiness", desc = "Requires external source — not yet defined", status = "Planned" }
            };

            var payload = new
            {
                totalRecords = rows.Count,
                checks,
                readiness
            };

            _cache.Set(responseCacheKey, payload, new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(3),
                SlidingExpiration = TimeSpan.FromMinutes(1)
            });

            return new JsonResult(payload);
        }
    }
}