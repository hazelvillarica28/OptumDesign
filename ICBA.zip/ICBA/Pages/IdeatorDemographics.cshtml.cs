﻿using ICBA.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Caching.Memory;
using Services.CacheService;
using Services.DataService;

namespace ICBA.Pages
{
    public class IdeatorDemographicsModel : PageModel
    {
        private readonly IBrightIdeaCacheService _baseDataService;
        private readonly IMemoryCache _cache;

        public IdeatorDemographicsModel(IBrightIdeaCacheService baseDataService, IMemoryCache cache)
        {
            _baseDataService = baseDataService;
            _cache = cache;
        }

        public DateTime AsOfDate { get; set; }
        public int TotalRecords { get; set; }
        public List<BrightIdeaDumpReportViewModel> BrightIdeaDumpReportList { get; set; } = new();

        public async Task OnGetAsync()
        {
            var data = await _baseDataService.GetBaseDataAsync();
            BrightIdeaDumpReportList = data;
            TotalRecords = data.Count;
            AsOfDate = DateTime.Today;
        }

        private static bool EqualsFilter(string? source, string? filter)
        {
            if (string.IsNullOrWhiteSpace(filter))
                return true;

            return string.Equals(
                source?.Trim(),
                filter.Trim(),
                StringComparison.OrdinalIgnoreCase);
        }

        public async Task<IActionResult> OnGetIdeatorDemographicsDataAsync(
            string? capability,
            string? business,
            string? geo,
            string? priority,
            string? stage,
            string? timeType,
            string? year,
            string? start,
            string? end)
        {
            var responseCacheKey = $"culture:v2:{capability}:{business}:{geo}:{priority}:{stage}:{timeType}:{year}:{start}:{end}";

            if (_cache.TryGetValue(responseCacheKey, out object? cached) && cached is not null)
                return new JsonResult(cached);

            var data = await _baseDataService.GetBaseDataAsync();
            var query = data.AsEnumerable();

            query = query.Where(x =>
                EqualsFilter(x.Capability, capability) &&
                EqualsFilter(x.BusinessName, business) &&
                EqualsFilter(x.Geographies, geo) &&
                EqualsFilter(x.Priorities, priority) &&
                EqualsFilter(x.FunnelStage, stage));

            if (string.Equals(timeType, "year", StringComparison.OrdinalIgnoreCase) && int.TryParse(year, out var y))
            {
                query = query.Where(x => x.CreatedOn.HasValue && x.CreatedOn.Value.Year == y);
            }
            else if (string.Equals(timeType, "range", StringComparison.OrdinalIgnoreCase))
            {
                DateTime? s = DateTime.TryParse(start, out var sv) ? sv.Date : null;
                DateTime? e = DateTime.TryParse(end, out var ev) ? ev.Date.AddDays(1).AddTicks(-1) : null;

                query = query.Where(x =>
                    x.CreatedOn.HasValue &&
                    (!s.HasValue || x.CreatedOn.Value >= s.Value) &&
                    (!e.HasValue || x.CreatedOn.Value <= e.Value));
            }

            var rows = query.ToList();

            bool IsAIIdeation(BrightIdeaDumpReportViewModel x) =>
                string.Equals((x.IdeaType ?? string.Empty).Trim(), "AI First Operations", StringComparison.OrdinalIgnoreCase);

            bool IsAISolution(BrightIdeaDumpReportViewModel x) =>
                string.Equals((x.IsAI ?? string.Empty).Trim(), "Yes", StringComparison.OrdinalIgnoreCase);

            bool IsAIProject(BrightIdeaDumpReportViewModel x) => IsAIIdeation(x) || IsAISolution(x);

            string AICategory(BrightIdeaDumpReportViewModel x)
            {
                var t = $"{x.IdeaTitle} {x.ThemeName} {x.SubThemeName} {x.Recommendation} {x.ProblemStatement}".ToLowerInvariant();
                bool Has(params string[] w) => w.Any(t.Contains);

                if (Has("knowledge", "sop ", "document", "content search", "wiki", "training material", "repository")) return "AI for Knowledge Management";
                if (Has("compliance", "audit", "regulatory", "quality", "accuracy", "control", " risk", "error rate")) return "AI for Quality and Compliance";
                if (Has("analytic", "insight", "decision", "predict", "forecast", "dashboard", "reporting", "model ")) return "AI-Powered Decision Support and Analytics";
                if (Has("customer", "member", "provider", "experience", "employee", "nps", "self service", "self-service", "advocate", "satisfaction")) return "AI for Customer and Employee Experience";
                return "AI for Productivity and Innovation";
            }

            var valid = rows.Count;

            var contributors = rows
                .Select(x => x.EmployeeID)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Count();

            var capabilitiesEngaged = rows
                .Select(x => x.Capability)
                .Where(x => !string.IsNullOrWhiteSpace(x) && x != "�")
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Count();

            var geographies = rows
                .Select(x => x.Geographies)
                .Where(x => !string.IsNullOrWhiteSpace(x) && x != "�")
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Count();

            var ideasPerContributor = contributors > 0 ? Math.Round((decimal)valid / contributors, 1) : 0m;

            var capabilityIdeas = rows
                .Where(x => !string.IsNullOrWhiteSpace(x.Capability) && x.Capability != "�")
                .GroupBy(x => x.Capability!)
                .Select(g => new { name = g.Key, count = g.Count() })
                .OrderByDescending(x => x.count)
                .Take(10)
                .ToList();

            var geoIdeas = rows
                .Where(x => !string.IsNullOrWhiteSpace(x.Geographies) && x.Geographies != "�")
                .GroupBy(x => x.Geographies!)
                .Select(g => new { name = g.Key, count = g.Count() })
                .OrderByDescending(x => x.count)
                .Take(7)
                .ToList();

            var themeIdeas = rows
                .Where(x => !string.IsNullOrWhiteSpace(x.ThemeName) && x.ThemeName != "�")
                .GroupBy(x => x.ThemeName!)
                .Select(g => new { name = g.Key, count = g.Count() })
                .OrderByDescending(x => x.count)
                .Take(10)
                .ToList();

            var aiThemeOrder = new[]
            {
                "AI for Customer and Employee Experience",
                "AI for Knowledge Management",
                "AI-Powered Decision Support and Analytics",
                "AI for Quality and Compliance",
                "AI for Productivity and Innovation"
            };

            var aiRows = rows.Where(IsAIProject).ToList();
            var aiTheme = aiThemeOrder
                .Select(c => new { name = c, count = aiRows.Count(r => AICategory(r) == c) })
                .ToList();

            var payload = new
            {
                totalRecords = rows.Count,
                kpis = new
                {
                    contributors,
                    ideasPerContributor,
                    capabilitiesEngaged,
                    geographies
                },
                capabilityIdeas,
                geoIdeas,
                themeIdeas,
                aiTheme
            };

            _cache.Set(responseCacheKey, payload, new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(3),
                SlidingExpiration = TimeSpan.FromMinutes(1)
            });

            return new JsonResult(payload);
        }
    }
}