﻿using ICBA.Models;
using ICBA.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Caching.Memory;
using Services.CacheService;
using Services.DataService;
using System.Diagnostics;
using System.Globalization;

namespace ICBA.Pages
{
    public class IndexModel : PageModel
    {

        private readonly IBrightIdeaCacheService _baseDataService;
        private readonly IMemoryCache _cache;

        public IndexModel(IBrightIdeaCacheService baseDataService, IMemoryCache cache)
        {
            _baseDataService = baseDataService;
            _cache = cache;
        }

        public DateTime AsOfDate { get; set; }
        public int TotalRecords { get; set; }
        public List<BrightIdeaDumpReportViewModel> BrightIdeaDumpReportList { get; set; } = new();

        public async Task OnGetAsync()
        {
            var data = await _baseDataService.GetBaseDataAsync();
            BrightIdeaDumpReportList = data;
            TotalRecords = data.Count;
            AsOfDate = DateTime.Today;
        }

        public async Task<IActionResult> OnGetLeadershipCockpitDataAsync(
        string? capability,
        string? business,
        string? geo,
        string? priority,
        string? stage,
        string? timeType,
        string? year,
        string? start,
        string? end,
        int? inApproval,
        int? approvedNoOwner,
        int? approvedWithPlan,
        int? inImplementation,
        int? implementedNotValidated,
        int? validated)
        {
            var w = PipelineForecastLogic.FromPercent(inApproval, approvedNoOwner, approvedWithPlan, inImplementation, implementedNotValidated, validated);

            var responseCacheKey = $"dash:v2:{capability}:{business}:{geo}:{priority}:{stage}:{timeType}:{year}:{start}:{end}:{inApproval}:{approvedNoOwner}:{approvedWithPlan}:{inImplementation}:{implementedNotValidated}:{validated}";

            if (_cache.TryGetValue(responseCacheKey, out object? cachedResponse) && cachedResponse is not null)
            {
                return new JsonResult(cachedResponse);
            }

            var data = await _baseDataService.GetBaseDataAsync();
            var query = data.AsEnumerable();

            if (!string.IsNullOrWhiteSpace(capability))
                query = query.Where(x => x.Capability == capability);

            if (!string.IsNullOrWhiteSpace(business))
                query = query.Where(x => x.BusinessName == business);

            if (!string.IsNullOrWhiteSpace(geo))
                query = query.Where(x => x.Geographies == geo);

            if (!string.IsNullOrWhiteSpace(priority))
                query = query.Where(x => x.Priorities == priority);

            if (!string.IsNullOrWhiteSpace(stage))
                query = query.Where(x => x.FunnelStage == stage);

            if (string.Equals(timeType, "year", StringComparison.OrdinalIgnoreCase) && int.TryParse(year, out var y))
            {
                query = query.Where(x => x.CreatedOn.HasValue && x.CreatedOn.Value.Year == y);
            }
            else if (string.Equals(timeType, "range", StringComparison.OrdinalIgnoreCase))
            {
                DateTime? s = DateTime.TryParse(start, out var sv) ? sv.Date : null;
                DateTime? e = DateTime.TryParse(end, out var ev) ? ev.Date.AddDays(1).AddTicks(-1) : null;

                query = query.Where(x =>
                    x.CreatedOn.HasValue &&
                    (!s.HasValue || x.CreatedOn.Value >= s.Value) &&
                    (!e.HasValue || x.CreatedOn.Value <= e.Value));
            }

            data = query.ToList();

            var ideasRaised = data.Count;

            var approvedCount = data.Count(x => string.Equals(x.FunnelStage, "Approved", StringComparison.OrdinalIgnoreCase));
            var implementedCount = data.Count(x => string.Equals(x.FunnelStage, "Implemented", StringComparison.OrdinalIgnoreCase));
            var backlogCount = data.Count(x => string.Equals(x.FunnelStage, "In Approval", StringComparison.OrdinalIgnoreCase));
            var rejectedCount = data.Count(x => string.Equals(x.FunnelStage, "Rejected", StringComparison.OrdinalIgnoreCase));
            var draftCount = data.Count(x => string.Equals(x.FunnelStage, "Draft", StringComparison.OrdinalIgnoreCase));

            var aiIdeation = data.Count(IsAIIdeation);
            var aiSolution = data.Count(IsAISolution);
            var aiAny = data.Count(IsAIProject);

            var nonAiIdeation = Math.Max(ideasRaised - aiIdeation, 0);
            var nonAiSolution = Math.Max(ideasRaised - aiSolution, 0);

            var aiBenefitEst = data.Sum(AiInitialBenefit);
            var aiRealized = data.Sum(x => x.RealizedAISavingsHard + x.RealizedAISavingsSoft);

            var realized = data.Sum(x => x.RealizedHardSavings + x.RealizedSoftSavings);
            var pipeline = data.Sum(x => x.ExpectedHard + x.ExpectedSoft);
            var weightedPipeline = PipelineForecastLogic.WeightedPipeline(data, w);
            var forecast = realized + weightedPipeline;

            var approvedPortfolio = data
                .Where(x => string.Equals(x.FunnelStage?.Trim(), "Approved", StringComparison.OrdinalIgnoreCase))
                .ToList();

            var approvedAiBenefit = approvedPortfolio
                .Where(IsAIProject)
                .Sum(x =>
                {
                    var ai = AiInitialBenefit(x);
                    return ai != 0m ? ai : IdeaExpectedValue(x);
                });

            var nonAiApprovedBenefit = approvedPortfolio
                .Where(x => !IsAIProject(x))
                .Sum(IdeaExpectedValue);

            static string RejectedBy(string? stageName)
            {
                var s = (stageName ?? string.Empty).ToLowerInvariant();
                if (s.Contains("ambassador") && s.Contains("reject")) return "Ambassador";
                if (s.Contains("manager") && s.Contains("reject")) return "Manager";
                return "Other";
            }

            var rejected = data
                .Where(x => string.Equals(x.FunnelStage, "Rejected", StringComparison.OrdinalIgnoreCase))
                .ToList();

            var rejectBy = rejected
                .GroupBy(x => RejectedBy(x.StageName), StringComparer.OrdinalIgnoreCase)
                .Select(g => new { name = g.Key, count = g.Count() })
                .Where(x => x.count > 0)
                .OrderByDescending(x => x.count)
                .ToArray();

            var rejectionReason = data
                .Where(x => string.Equals(x.FunnelStage, "Rejected", StringComparison.OrdinalIgnoreCase))
                .SelectMany(x => new[] { x.BBComments, x.MgrComments })
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x!.Trim())
                .GroupBy(x => x, StringComparer.OrdinalIgnoreCase)
                .Select(g => new { name = g.First(), count = g.Count() })
                .OrderByDescending(x => x.count);

            var monthly = data
                .Where(x => x.CreatedOn.HasValue)
                .GroupBy(x => x.CreatedOn!.Value.Month)
                .OrderBy(g => g.Key)
                .Select(g =>
                {
                    var monthRows = g.ToList();
                    var monthTotal = monthRows.Count;
                    var monthApproved = monthRows.Count(x => string.Equals(x.FunnelStage, "Approved", StringComparison.OrdinalIgnoreCase));
                    var monthApprovalRate = monthTotal == 0 ? 0 : Math.Round((decimal)monthApproved / monthTotal * 100m, 1);

                    return new
                    {
                        name = CultureInfo.InvariantCulture.DateTimeFormat.AbbreviatedMonthNames[g.Key - 1],
                        count = monthTotal,
                        approvalRate = monthApprovalRate,
                        rate = monthApprovalRate
                    };
                });

            var payload = new
            {
                totalRecords = ideasRaised,
                kpis = new
                {
                    ideasRaised,
                    valid = ideasRaised,
                    approved = approvedCount,
                    implemented = implementedCount,
                    backlog = backlogCount,
                    rejected = rejectedCount,
                    draft = draftCount,
                    aiIdeation,
                    aiSolution,
                    aiAny,
                    nonAiIdeation,
                    nonAiSolution,
                    aiBenefitEst,
                    aiRealized,
                    realized,
                    pipeline,
                    weightedPipeline,
                    forecast,
                    approvedAiBenefit,
                    nonAiApprovedBenefit
                },
                monthly,

                capability = data
                    .Where(x => !string.IsNullOrWhiteSpace(x.Capability))
                    .GroupBy(x => x.Capability!)
                    .Select(g => new { name = g.Key, count = g.Count() })
                    .OrderByDescending(x => x.count),

                geo = data
                    .Where(x => !string.IsNullOrWhiteSpace(x.Geographies))
                    .GroupBy(x => x.Geographies!)
                    .Select(g => new { name = g.Key, count = g.Count() })
                    .OrderByDescending(x => x.count),

                priority = data
                    .Where(x => !string.IsNullOrWhiteSpace(x.Priorities))
                    .GroupBy(x => x.Priorities!)
                    .Select(g => new { name = g.Key, count = g.Count() })
                    .OrderByDescending(x => x.count),

                stage = data
                    .Where(x => !string.IsNullOrWhiteSpace(x.FunnelStage))
                    .GroupBy(x => x.FunnelStage!)
                    .Select(g => new { name = g.Key, count = g.Count() })
                    .OrderByDescending(x => x.count),

                rejectBy,
                rejectionReason
            };

            _cache.Set(responseCacheKey, payload, new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(3),
                SlidingExpiration = TimeSpan.FromMinutes(1)
            });

            return new JsonResult(payload);
        }

        

        private static bool IsAIIdeation(BrightIdeaDumpReportViewModel x) =>
            string.Equals(x.IdeaType?.Trim(), "AI First Operations", StringComparison.OrdinalIgnoreCase);

        private static bool IsAISolution(BrightIdeaDumpReportViewModel x) =>
            string.Equals(x.IsAI?.Trim(), "Yes", StringComparison.OrdinalIgnoreCase);

        private static bool IsAIProject(BrightIdeaDumpReportViewModel x) => IsAIIdeation(x) || IsAISolution(x);

        private static decimal IdeaExpectedValue(BrightIdeaDumpReportViewModel x)
        {
            var expected = x.ExpectedHard + x.ExpectedSoft;
            return expected != 0m ? expected : x.PotentialSavings;
        }

        private static decimal AiInitialBenefit(BrightIdeaDumpReportViewModel x) =>
            x.InitialBenefitEstimateAISavings;
    }
}