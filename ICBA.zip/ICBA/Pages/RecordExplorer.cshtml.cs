using ICBA.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Caching.Memory;
using Services.CacheService;
using Services.DataService;

namespace ICBA.Pages
{
    public class RecordExplorerModel : PageModel
    {
        private readonly IBrightIdeaCacheService _baseDataService;
        private readonly IMemoryCache _cache;

        public RecordExplorerModel(IBrightIdeaCacheService baseDataService, IMemoryCache cache)
        {
            _baseDataService = baseDataService;
            _cache = cache;
        }

        public DateTime AsOfDate { get; set; }
        public int TotalRecords { get; set; }
        public List<BrightIdeaDumpReportViewModel> BrightIdeaDumpReportList { get; set; } = new();

        public async Task OnGetAsync()
        {
            var data = await _baseDataService.GetBaseDataAsync();
            BrightIdeaDumpReportList = data;
            TotalRecords = data.Count;
            AsOfDate = DateTime.Today;
        }

        private static bool EqualsFilter(string? source, string? filter)
        {
            if (string.IsNullOrWhiteSpace(filter))
                return true;

            return string.Equals(
                source?.Trim(),
                filter.Trim(),
                StringComparison.OrdinalIgnoreCase);
        }

        public async Task<IActionResult> OnGetRecordExplorerDataAsync(
            string? capability,
            string? business,
            string? geo,
            string? priority,
            string? stage,
            string? timeType,
            string? year,
            string? start,
            string? end)
        {
            var responseCacheKey = $"records:v2:{capability}:{business}:{geo}:{priority}:{stage}:{timeType}:{year}:{start}:{end}";
            if (_cache.TryGetValue(responseCacheKey, out object? cached) && cached is not null)
                return new JsonResult(cached);

            var data = await _baseDataService.GetBaseDataAsync();
            var query = data.AsEnumerable();

            query = query.Where(x =>
                EqualsFilter(x.Capability, capability) &&
                EqualsFilter(x.BusinessName, business) &&
                EqualsFilter(x.Geographies, geo) &&
                EqualsFilter(x.Priorities, priority) &&
                EqualsFilter(x.FunnelStage, stage));

            if (string.Equals(timeType, "year", StringComparison.OrdinalIgnoreCase) && int.TryParse(year, out var y))
            {
                query = query.Where(x => x.CreatedOn.HasValue && x.CreatedOn.Value.Year == y);
            }
            else if (string.Equals(timeType, "range", StringComparison.OrdinalIgnoreCase))
            {
                DateTime? s = DateTime.TryParse(start, out var sv) ? sv.Date : null;
                DateTime? e = DateTime.TryParse(end, out var ev) ? ev.Date.AddDays(1).AddTicks(-1) : null;

                query = query.Where(x =>
                    x.CreatedOn.HasValue &&
                    (!s.HasValue || x.CreatedOn.Value >= s.Value) &&
                    (!e.HasValue || x.CreatedOn.Value <= e.Value));
            }

            var rows = query.ToList();

            var records = rows.Select(x => new Dictionary<string, object?>
            {
                ["IdeaID"] = x.IdeaID ?? "",
                ["CreatedOn"] = x.CreatedOn?.ToString("dd MMM yyyy") ?? "",
                ["Capability"] = x.Capability ?? "",
                ["BusinessName"] = x.BusinessName ?? "",
                ["Stage_Name"] = x.StageName ?? "",
                ["__funnel"] = x.FunnelStage ?? "",
                ["enterprise priorities"] = x.Priorities ?? "",
                ["ThemeName"] = x.ThemeName ?? "",
                ["Geo"] = x.Geographies ?? "",
                ["Hard Savings"] = x.RealizedHardSavings,
                ["Soft Savings"] = x.RealizedSoftSavings,
                ["Pipeline Hard"] = x.ExpectedHard,
                ["Pipeline Soft"] = x.ExpectedSoft,
                ["AmbassadorName"] = x.AmbassadorName ?? "",
                ["IdeaValidated"] = x.IdeaValidated ?? "",
                ["IdeaTitle"] = x.IdeaTitle ?? "",
                ["FunctionName"] = x.FunctionName ?? ""
            }).ToList();

            var payload = new
            {
                totalRecords = records.Count,
                records
            };

            _cache.Set(responseCacheKey, payload, new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(3),
                SlidingExpiration = TimeSpan.FromMinutes(1)
            });

            return new JsonResult(payload);
        }
    }
}