using ICBA.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Caching.Memory;
using Services.CacheService;
using Services.DataService;

namespace ICBA.Pages
{
    public class GovernanceFlowModel : PageModel
    {
        private readonly IBrightIdeaCacheService _baseDataService;
        private readonly IMemoryCache _cache;

        public GovernanceFlowModel(IBrightIdeaCacheService baseDataService, IMemoryCache cache)
        {
            _baseDataService = baseDataService;
            _cache = cache;
        }

        public DateTime AsOfDate { get; set; }
        public int TotalRecords { get; set; }
        public List<BrightIdeaDumpReportViewModel> BrightIdeaDumpReportList { get; set; } = new();

        public async Task OnGetAsync()
        {
            var data = await _baseDataService.GetBaseDataAsync();
            BrightIdeaDumpReportList = data;
            TotalRecords = data.Count;
            AsOfDate = DateTime.Today;
        }

        private static bool EqualsFilter(string? source, string? filter)
        {
            if (string.IsNullOrWhiteSpace(filter))
                return true;

            return string.Equals(
                source?.Trim(),
                filter.Trim(),
                StringComparison.OrdinalIgnoreCase);
        }

        public async Task<IActionResult> OnGetGovernanceFlowDataAsync(
            string? capability,
            string? business,
            string? geo,
            string? priority,
            string? stage,
            string? timeType,
            string? year,
            string? start,
            string? end)
        {
            var responseCacheKey = $"gf:v2:{capability}:{business}:{geo}:{priority}:{stage}:{timeType}:{year}:{start}:{end}";

            if (_cache.TryGetValue(responseCacheKey, out object? cachedResponse) && cachedResponse is not null)
            {
                return new JsonResult(cachedResponse);
            }

            var data = await _baseDataService.GetBaseDataAsync();
            var query = data.AsEnumerable();

            query = query.Where(x =>
                EqualsFilter(x.Capability, capability) &&
                EqualsFilter(x.BusinessName, business) &&
                EqualsFilter(x.Geographies, geo) &&
                EqualsFilter(x.Priorities, priority) &&
                EqualsFilter(x.FunnelStage, stage));

            if (string.Equals(timeType, "year", StringComparison.OrdinalIgnoreCase) && int.TryParse(year, out var y))
            {
                query = query.Where(x => x.CreatedOn.HasValue && x.CreatedOn.Value.Year == y);
            }
            else if (string.Equals(timeType, "range", StringComparison.OrdinalIgnoreCase))
            {
                DateTime? s = DateTime.TryParse(start, out var sv) ? sv.Date : null;
                DateTime? e = DateTime.TryParse(end, out var ev) ? ev.Date.AddDays(1).AddTicks(-1) : null;

                query = query.Where(x =>
                    x.CreatedOn.HasValue &&
                    (!s.HasValue || x.CreatedOn.Value >= s.Value) &&
                    (!e.HasValue || x.CreatedOn.Value <= e.Value));
            }

            data = query.ToList();

            var valid = data.Count;
            var approved = data.Count(x => string.Equals(x.FunnelStage, "Approved", StringComparison.OrdinalIgnoreCase));
            var rejected = data.Count(x => string.Equals(x.FunnelStage, "Rejected", StringComparison.OrdinalIgnoreCase));
            var backlog = data.Count(x => PendingStepName(x) == "Manager approval" || PendingStepName(x) == "Ambassador approval");
            var avgDecisionAge = AvgDays(data);

            var stageItems = data
                .Where(x => !string.IsNullOrWhiteSpace(x.FunnelStage))
                .GroupBy(x => x.FunnelStage!)
                .Select(g => new { name = g.Key, count = g.Count() })
                .OrderByDescending(x => x.count);

            var capabilityBacklog = data
                .Where(x => string.Equals(x.FunnelStage, "In Approval", StringComparison.OrdinalIgnoreCase) &&
                            !string.IsNullOrWhiteSpace(x.Capability))
                .GroupBy(x => x.Capability!)
                .Select(g => new { name = g.Key, count = g.Count() })
                .OrderByDescending(x => x.count);

            var backlogStep = data
                .Select(x => PendingStepName(x))
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .GroupBy(x => x!)
                .Select(g => new { name = g.Key, count = g.Count() })
                .OrderByDescending(x => x.count);

            var backlogRows = data
                .Where(x => !string.IsNullOrWhiteSpace(PendingStepName(x)))
                .ToList();

            var rejectBy = new[]
            {
                new
                {
                    name = "Manager",
                    count = backlogRows.Count(x =>
                        (x.StageName ?? string.Empty).Contains("manager", StringComparison.OrdinalIgnoreCase))
                },
                new
                {
                    name = "Ambassador",
                    count = backlogRows.Count(x =>
                        (x.StageName ?? string.Empty).Contains("ambassador", StringComparison.OrdinalIgnoreCase))
                },
                new
                {
                    name = "User implementation",
                    count = backlogRows.Count(x =>
                        (x.StageName ?? string.Empty).Contains("user implementation", StringComparison.OrdinalIgnoreCase))
                }
            }
            .Where(x => x.count > 0)
            .ToArray();

            string? PendingStepName(BrightIdeaDumpReportViewModel x)
            {
                var s = (x.StageName ?? string.Empty).ToLowerInvariant();

                if (s.Contains("pending for manager approval")) return "Manager approval";
                if (s.Contains("pending for ambassador approval")) return "Ambassador approval";
                if (s.Contains("pending manager for implementation")) return "Manager sign-off (implementation)";
                if (s.Contains("pending ambassador for implementation")) return "Ambassador sign-off (implementation)";
                if (s.Contains("pending user implementation")) return "User implementation";

                return null;
            }

            string ClassifyRejectionReason(BrightIdeaDumpReportViewModel x)
            {
                var txt = $"{x.MgrComments ?? string.Empty} {x.BBComments ?? string.Empty}"
                    .Trim()
                    .ToLowerInvariant();

                if (string.IsNullOrWhiteSpace(txt) || txt == "-") return "No reason captured";
                if (txt.Contains("duplicate")) return "Duplicate idea";
                if (txt.Contains("already") || txt.Contains("exist") || txt.Contains("in place") || txt.Contains("implemented")) return "Already exists / in place";
                if (txt.Contains("not feasible") || txt.Contains("feasib") || txt.Contains("cannot") || txt.Contains("not possible")) return "Not feasible";
                if (txt.Contains("no benefit") || txt.Contains("no saving") || txt.Contains("not beneficial") || txt.Contains("low value")) return "Insufficient benefit";
                if (txt.Contains("not needed") || txt.Contains("no need") || txt.Contains("not required")) return "Not needed";
                if (txt.Contains("scope") || txt.Contains("out of")) return "Out of scope";
                if (txt.Contains("incomplete") || txt.Contains("more detail") || txt.Contains("clarif") || txt.Contains("insufficient")) return "Incomplete / needs detail";

                return "Other reasons";
            }

            bool IsStage(BrightIdeaDumpReportViewModel x, string token) =>
                (x.StageName ?? string.Empty).Contains(token, StringComparison.OrdinalIgnoreCase);

            var inApprovalRows = data
                .Where(x => string.Equals(x.FunnelStage, "In Approval", StringComparison.OrdinalIgnoreCase))
                .ToList();

            var inImplementationRows = data
                .Where(x => string.Equals(x.FunnelStage, "In Implementation", StringComparison.OrdinalIgnoreCase))
                .ToList();

            var approvedRows = data
                .Where(x => string.Equals(x.FunnelStage, "Approved", StringComparison.OrdinalIgnoreCase))
                .ToList();

            var managerRows = data.Where(x => PendingStepName(x) == "Manager approval").ToList();
            var ambassadorRows = data.Where(x => PendingStepName(x) == "Ambassador approval").ToList();
            var implSignoffRows = data.Where(x =>
            {
                var step = PendingStepName(x);
                return step == "Manager sign-off (implementation)" || step == "Ambassador sign-off (implementation)";
            }).ToList();
            var userImplRows = data.Where(x => PendingStepName(x) == "User implementation").ToList();

            if (managerRows.Count == 0)
                managerRows = inApprovalRows.Where(x => string.IsNullOrWhiteSpace(x.AmbassadorName)).ToList();

            if (ambassadorRows.Count == 0)
                ambassadorRows = inApprovalRows.Where(x => !string.IsNullOrWhiteSpace(x.AmbassadorName)).ToList();

            if (implSignoffRows.Count == 0)
                implSignoffRows = inImplementationRows;

            if (userImplRows.Count == 0)
                userImplRows = approvedRows;

            var rejectedRows = data
                .Where(x => string.Equals(x.FunnelStage, "Rejected", StringComparison.OrdinalIgnoreCase))
                .ToList();

            var rejectionReason = data
                .Where(x => string.Equals(x.FunnelStage, "Rejected", StringComparison.OrdinalIgnoreCase))
                .Select(ClassifyRejectionReason)
                .GroupBy(x => x, StringComparer.OrdinalIgnoreCase)
                .Select(g => new { name = g.Key, count = g.Count() })
                .OrderByDescending(x => x.count);

            var aiByCapability = data
                .Where(x => !string.IsNullOrWhiteSpace(x.Capability))
                .GroupBy(x => x.Capability!)
                .Select(g => new
                {
                    capability = g.Key,
                    aiIdeation = g.Count(x =>
                        string.Equals((x.IdeaType ?? string.Empty).Trim(), "AI First Operations", StringComparison.OrdinalIgnoreCase)),
                    aiSolution = g.Count(x =>
                        string.Equals((x.IsAI ?? string.Empty).Trim(), "Yes", StringComparison.OrdinalIgnoreCase))
                })
                .Where(x => x.aiIdeation > 0 || x.aiSolution > 0)
                .OrderByDescending(x => x.aiIdeation + x.aiSolution)
                .ToList();

            var payload = new
            {
                totalRecords = data.Count,
                kpis = new { valid, approved, rejected, backlog, avgDecisionAge },
                stage = stageItems,
                capabilityBacklog,
                backlogStep,
                rejectBy,
                rejectionReason,
                processOwners = new[]
                {
                    new { step = "Manager approval", owner = "Reporting manager", pending = managerRows.Count, avgDays = AvgDays(managerRows) },
                    new { step = "Ambassador approval", owner = "Business ambassador", pending = ambassadorRows.Count, avgDays = AvgDays(ambassadorRows) },
                    new { step = "Implementation sign-off", owner = "Manager / ambassador", pending = implSignoffRows.Count, avgDays = AvgDays(implSignoffRows) },
                    new { step = "User implementation", owner = "Idea owner", pending = userImplRows.Count, avgDays = AvgDays(userImplRows) }
                },
                aiByCapability
            };

            _cache.Set(responseCacheKey, payload, new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(3),
                SlidingExpiration = TimeSpan.FromMinutes(1)
            });

            return new JsonResult(payload);
        }

        private static decimal DecisionAgeDays(BrightIdeaDumpReportViewModel x)
        {
            if (!x.CreatedOn.HasValue || !x.ModifiedOn.HasValue)
                return 0m;

            var days = (decimal)(x.ModifiedOn.Value.Date - x.CreatedOn.Value.Date).TotalDays;
            return days < 0 ? 0m : days;
        }

        private static decimal AvgDays(IEnumerable<BrightIdeaDumpReportViewModel> rows)
        {
            var list = rows.ToList();
            if (list.Count == 0) return 0m;

            var sum = list.Sum(DecisionAgeDays);
            return Math.Round(sum / list.Count, 1);
        }
    }
}