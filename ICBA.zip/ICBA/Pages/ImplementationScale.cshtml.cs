using ICBA.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Caching.Memory;
using Services.CacheService;
using Services.DataService;

namespace ICBA.Pages
{
    public class ImplementationScaleModel : PageModel
    {
        private readonly IBrightIdeaCacheService _baseDataService;
        private readonly IMemoryCache _cache;

        public ImplementationScaleModel(IBrightIdeaCacheService baseDataService, IMemoryCache cache)
        {
            _baseDataService = baseDataService;
            _cache = cache;
        }

        public DateTime AsOfDate { get; set; }
        public int TotalRecords { get; set; }
        public List<BrightIdeaDumpReportViewModel> BrightIdeaDumpReportList { get; set; } = new();

        public async Task OnGetAsync()
        {
            var data = await _baseDataService.GetBaseDataAsync();
            BrightIdeaDumpReportList = data;
            TotalRecords = data.Count;
            AsOfDate = DateTime.Today;
        }

        private static bool EqualsFilter(string? source, string? filter)
        {
            if (string.IsNullOrWhiteSpace(filter))
                return true;

            return string.Equals(
                source?.Trim(),
                filter.Trim(),
                StringComparison.OrdinalIgnoreCase);
        }

        public async Task<IActionResult> OnGetImplementationScaleDataAsync(
            string? capability,
            string? business,
            string? geo,
            string? priority,
            string? stage,
            string? timeType,
            string? year,
            string? start,
            string? end)
        {
            var responseCacheKey = $"impl:v2:{capability}:{business}:{geo}:{priority}:{stage}:{timeType}:{year}:{start}:{end}";

            if (_cache.TryGetValue(responseCacheKey, out object? cachedResponse) && cachedResponse is not null)
            {
                return new JsonResult(cachedResponse);
            }

            var data = await GetBaseDataAsync();
            var query = data.AsEnumerable();

            query = query.Where(x =>
                EqualsFilter(x.Capability, capability) &&
                EqualsFilter(x.BusinessName, business) &&
                EqualsFilter(x.Geographies, geo) &&
                EqualsFilter(x.Priorities, priority) &&
                EqualsFilter(x.FunnelStage, stage));

            if (string.Equals(timeType, "year", StringComparison.OrdinalIgnoreCase) && int.TryParse(year, out var y))
            {
                query = query.Where(x => x.CreatedOn.HasValue && x.CreatedOn.Value.Year == y);
            }
            else if (string.Equals(timeType, "range", StringComparison.OrdinalIgnoreCase))
            {
                DateTime? s = DateTime.TryParse(start, out var sv) ? sv.Date : null;
                DateTime? e = DateTime.TryParse(end, out var ev) ? ev.Date.AddDays(1).AddTicks(-1) : null;

                query = query.Where(x =>
                    x.CreatedOn.HasValue &&
                    (!s.HasValue || x.CreatedOn.Value >= s.Value) &&
                    (!e.HasValue || x.CreatedOn.Value <= e.Value));
            }

            var rows = query.ToList();

            static bool IsStageLike(BrightIdeaDumpReportViewModel x, string stageName)
            {
                if (string.Equals(x.FunnelStage?.Trim(), stageName, StringComparison.OrdinalIgnoreCase)) return true;
                return (x.StageName ?? string.Empty).IndexOf(stageName, StringComparison.OrdinalIgnoreCase) >= 0;
            }

            bool IsAIIdeation(BrightIdeaDumpReportViewModel x) =>
                string.Equals((x.IdeaType ?? string.Empty).Trim(), "AI First Operations", StringComparison.OrdinalIgnoreCase);

            bool IsAISolution(BrightIdeaDumpReportViewModel x) =>
                string.Equals((x.IsAI ?? string.Empty).Trim(), "Yes", StringComparison.OrdinalIgnoreCase);

            bool IsAIProject(BrightIdeaDumpReportViewModel x) => IsAIIdeation(x) || IsAISolution(x);

            string AirbStatus(BrightIdeaDumpReportViewModel x)
            {
                var s = (x.AIRBStatus ?? string.Empty).Trim().ToLowerInvariant();
                if (string.IsNullOrWhiteSpace(s) || s == "unspecified" || s == "#n/a") return "Not applicable";
                if (s.Contains("approve")) return "Approved";
                if (s.Contains("not yet")) return "Not submitted";
                if (s.Contains("review") || s.Contains("progress")) return "In review";
                if (s.Contains("reject")) return "Rejected";
                return "Other";
            }

            decimal IdeaExpectedValue(BrightIdeaDumpReportViewModel x)
            {
                var expected = x.ExpectedHard + x.ExpectedSoft;
                return expected != 0m ? expected : x.PotentialSavings;
            }

            decimal IdeaRealizedValue(BrightIdeaDumpReportViewModel x)
            {
                var realized = x.RealizedHardSavings + x.RealizedSoftSavings;
                return realized != 0m ? realized : (x.ExpectedHard + x.ExpectedSoft);
            }

            var valid = rows.Count;
            var approvedRows = rows.Where(x => IsStageLike(x, "Approved")).ToList();
            var implementedRows = rows.Where(x => IsStageLike(x, "Implemented")).ToList();
            var inImplementationRows = rows.Where(x => IsStageLike(x, "In Implementation")).ToList();

            var approved = approvedRows.Count;
            var implemented = implementedRows.Count;
            var notImplemented = Math.Max(approved - implemented, 0);

            var scaled = implementedRows.Count(x =>
            {
                var v = (x.IdeaValidated ?? string.Empty).ToLowerInvariant();
                return v.Contains("validated") && !v.Contains("not");
            });

            var submitToImplementRate = valid > 0 ? (decimal)implemented / valid : 0m;
            var approveToImplementRate = approved > 0 ? (decimal)implemented / approved : 0m;

            var cbaImplemented = implementedRows.Sum(IdeaRealizedValue);
            var cbaApprovedNotImpl = approvedRows.Where(x => !IsStageLike(x, "Implemented")).Sum(IdeaExpectedValue);

            var kpis = new
            {
                valid,
                approved,
                implemented,
                notImplemented,
                scaled,
                submitToImplementRate,
                approveToImplementRate,
                cbaImplemented,
                cbaApprovedNotImpl
            };

            var funnelSteps = new[]
            {
                new { name = "Total submissions", count = valid, baseCount = valid },
                new { name = "Full approval (all gates)", count = approved, baseCount = valid },
                new { name = "Implemented", count = implemented, baseCount = approved },
                new { name = "Scaled / validated", count = scaled, baseCount = implemented }
            };

            var stagePipeline = new[]
            {
                new { name = "Approved", count = approved },
                new { name = "In implementation", count = inImplementationRows.Count },
                new { name = "Implemented", count = implemented }
            };

            var conversionByCapability = rows
                .Where(x => !string.IsNullOrWhiteSpace(x.Capability))
                .GroupBy(x => x.Capability!)
                .Select(g =>
                {
                    var total = g.Count();
                    var app = g.Count(x => IsStageLike(x, "Approved"));
                    var impl = g.Count(x => IsStageLike(x, "Implemented"));
                    return new
                    {
                        capability = g.Key,
                        total,
                        approvalRate = total > 0 ? Math.Round((decimal)app * 100m / total, 0) : 0m,
                        implementationRate = total > 0 ? Math.Round((decimal)impl * 100m / total, 0) : 0m
                    };
                })
                .OrderByDescending(x => x.total)
                .Take(7)
                .Select(x => new { x.capability, x.approvalRate, x.implementationRate })
                .ToList();

            var aiRows = rows.Where(IsAIProject).ToList();
            var need = aiRows.Count;
            var approvedAirb = aiRows.Count(x => AirbStatus(x) == "Approved");
            var notSubmitted = aiRows.Count(x => AirbStatus(x) == "Not submitted");
            var implementedNoAirb = aiRows.Count(x => IsStageLike(x, "Implemented") && AirbStatus(x) != "Approved");

            var airbStatus = new[] { "Approved", "In review", "Not submitted", "Rejected", "Other", "Not applicable" }
                .Select(s => new { name = s, count = aiRows.Count(x => AirbStatus(x) == s) })
                .Where(x => x.count > 0)
                .ToList();

            var airbKpis = new
            {
                need,
                approved = approvedAirb,
                notSubmitted,
                implementedNoAirb
            };

            var payload = new
            {
                totalRecords = rows.Count,
                kpis,
                funnelSteps,
                stagePipeline,
                conversionByCapability,
                airbStatus,
                airbKpis
            };

            _cache.Set(responseCacheKey, payload, new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(3),
                SlidingExpiration = TimeSpan.FromMinutes(1)
            });

            return new JsonResult(payload);
        }

        private async Task<List<BrightIdeaDumpReportViewModel>> GetBaseDataAsync()
        {
            const string baseCacheKey = "baseData:implementation:v1:no-params";

            if (_cache.TryGetValue(baseCacheKey, out List<BrightIdeaDumpReportViewModel>? cached) && cached is not null)
                return cached;

            var data = await _baseDataService.GetBaseDataAsync();

            _cache.Set(baseCacheKey, data, new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(10),
                SlidingExpiration = TimeSpan.FromMinutes(5),
                Priority = CacheItemPriority.High
            });

            return data;
        }
    }
}