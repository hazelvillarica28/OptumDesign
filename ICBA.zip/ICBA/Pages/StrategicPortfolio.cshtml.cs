using ICBA.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Caching.Memory;
using Services.CacheService;
using Services.DataService;

namespace ICBA.Pages
{
    public class StrategicPortfolioModel : PageModel
    {
        private readonly IBrightIdeaCacheService _baseDataService;
        private readonly IMemoryCache _cache;

        public StrategicPortfolioModel(IBrightIdeaCacheService baseDataService, IMemoryCache cache)
        {
            _baseDataService = baseDataService;
            _cache = cache;
        }

        public DateTime AsOfDate { get; set; }
        public int TotalRecords { get; set; }
        public List<BrightIdeaDumpReportViewModel> BrightIdeaDumpReportList { get; set; } = new();

        public async Task OnGetAsync()
        {
            var data = await _baseDataService.GetBaseDataAsync();
            BrightIdeaDumpReportList = data;
            TotalRecords = data.Count;
            AsOfDate = DateTime.Today;
        }

        private static bool EqualsFilter(string? source, string? filter)
        {
            if (string.IsNullOrWhiteSpace(filter))
                return true;

            return string.Equals(
                source?.Trim(),
                filter.Trim(),
                StringComparison.OrdinalIgnoreCase);
        }

        public async Task<IActionResult> OnGetStrategicPortfolioDataAsync(
            string? capability,
            string? business,
            string? geo,
            string? priority,
            string? stage,
            string? timeType,
            string? year,
            string? start,
            string? end)
        {
            var responseCacheKey = $"sp:v3:{capability}:{business}:{geo}:{priority}:{stage}:{timeType}:{year}:{start}:{end}";

            if (_cache.TryGetValue(responseCacheKey, out object? cachedResponse) && cachedResponse is not null)
            {
                return new JsonResult(cachedResponse);
            }

            var data = await _baseDataService.GetBaseDataAsync();
            var query = data.AsEnumerable();

            query = query.Where(x =>
                EqualsFilter(x.Capability, capability) &&
                EqualsFilter(x.BusinessName, business) &&
                EqualsFilter(x.Geographies, geo) &&
                EqualsFilter(x.Priorities, priority) &&
                EqualsFilter(x.FunnelStage, stage));

            if (string.Equals(timeType, "year", StringComparison.OrdinalIgnoreCase) && int.TryParse(year, out var y))
            {
                query = query.Where(x => x.CreatedOn.HasValue && x.CreatedOn.Value.Year == y);
            }
            else if (string.Equals(timeType, "range", StringComparison.OrdinalIgnoreCase))
            {
                DateTime? s = DateTime.TryParse(start, out var sv) ? sv.Date : null;
                DateTime? e = DateTime.TryParse(end, out var ev) ? ev.Date.AddDays(1).AddTicks(-1) : null;

                query = query.Where(x =>
                    x.CreatedOn.HasValue &&
                    (!s.HasValue || x.CreatedOn.Value >= s.Value) &&
                    (!e.HasValue || x.CreatedOn.Value <= e.Value));
            }

            data = query.ToList();
            var totalRecords = data.Count;

            static bool IsApprovedLike(BrightIdeaDumpReportViewModel x)
            {
                if (string.Equals(x.FunnelStage?.Trim(), "Approved", StringComparison.OrdinalIgnoreCase))
                    return true;

                var stageName = (x.StageName ?? string.Empty).ToLowerInvariant();
                return stageName.Contains("approved");
            }

            var capabilityStats = data
                .Where(x => !string.IsNullOrWhiteSpace(x.Capability))
                .GroupBy(x => x.Capability!)
                .Select(g =>
                {
                    var total = g.Count();
                    var approved = g.Count(IsApprovedLike);
                    var approvalRate = total == 0 ? 0m : Math.Round((decimal)approved / total * 100m, 1);

                    return new
                    {
                        name = g.Key,
                        count = total,
                        approvalRate
                    };
                })
                .OrderByDescending(x => x.count)
                .ToList();

            var priorityStats = data
                .Where(x => !string.IsNullOrWhiteSpace(x.Priorities))
                .GroupBy(x => x.Priorities!)
                .Select(g => new { name = g.Key, count = g.Count() })
                .OrderByDescending(x => x.count)
                .ToList();

            var topCapabilities = capabilityStats.Take(6).Select(x => x.name).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var topPriorities = priorityStats.Take(7).Select(x => x.name).ToHashSet(StringComparer.OrdinalIgnoreCase);

            var capabilityPriority = data
                .Where(x =>
                    !string.IsNullOrWhiteSpace(x.Capability) &&
                    !string.IsNullOrWhiteSpace(x.Priorities) &&
                    topCapabilities.Contains(x.Capability!) &&
                    topPriorities.Contains(x.Priorities!))
                .GroupBy(x => new { x.Capability, x.Priorities })
                .Select(g => new
                {
                    capability = g.Key.Capability,
                    priority = g.Key.Priorities,
                    count = g.Count()
                })
                .ToList();

            var payload = new
            {
                totalRecords,
                capability = capabilityStats,
                priority = priorityStats.Take(7),
                capabilityPriority
            };

            _cache.Set(responseCacheKey, payload, new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(3),
                SlidingExpiration = TimeSpan.FromMinutes(1)
            });

            return new JsonResult(payload);
        }
    }
}