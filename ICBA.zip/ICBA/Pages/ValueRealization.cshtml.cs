using ICBA.Models;
using ICBA.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Caching.Memory;
using Services.CacheService;
using Services.DataService;

namespace ICBA.Pages
{
    public class ValueRealizationModel : PageModel
    {
        private readonly IBrightIdeaCacheService _baseDataService;
        private readonly IMemoryCache _cache;

        public ValueRealizationModel(IBrightIdeaCacheService baseDataService, IMemoryCache cache)
        {
            _baseDataService = baseDataService;
            _cache = cache;
        }

        public DateTime AsOfDate { get; set; }
        public int TotalRecords { get; set; }
        public List<BrightIdeaDumpReportViewModel> BrightIdeaDumpReportList { get; set; } = new();

        public async Task OnGetAsync()
        {
            var data = await _baseDataService.GetBaseDataAsync();
            BrightIdeaDumpReportList = data;
            TotalRecords = data.Count;
            AsOfDate = DateTime.Today;
        }

        private static bool EqualsFilter(string? source, string? filter)
        {
            if (string.IsNullOrWhiteSpace(filter))
                return true;

            return string.Equals(
                source?.Trim(),
                filter.Trim(),
                StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsStageLike(BrightIdeaDumpReportViewModel x, string stageName)
        {
            if (string.Equals(x.FunnelStage?.Trim(), stageName, StringComparison.OrdinalIgnoreCase))
                return true;

            return (x.StageName ?? string.Empty)
                .IndexOf(stageName, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        public async Task<IActionResult> OnGetValueRealizationDataAsync(
            string? capability,
            string? business,
            string? geo,
            string? priority,
            string? stage,
            string? timeType,
            string? year,
            string? start,
            string? end,
            int? inApproval,
            int? approvedNoOwner,
            int? approvedWithPlan,
            int? inImplementation,
            int? implementedNotValidated,
            int? validated)
        {
            var w = PipelineForecastLogic.FromPercent(
                inApproval,
                approvedNoOwner,
                approvedWithPlan,
                inImplementation,
                implementedNotValidated,
                validated);

            var responseCacheKey =
                $"value:v3:{capability}:{business}:{geo}:{priority}:{stage}:{timeType}:{year}:{start}:{end}:{inApproval}:{approvedNoOwner}:{approvedWithPlan}:{inImplementation}:{implementedNotValidated}:{validated}";

            if (_cache.TryGetValue(responseCacheKey, out object? cachedResponse) && cachedResponse is not null)
                return new JsonResult(cachedResponse);

            var data = await _baseDataService.GetBaseDataAsync();
            var query = data.AsEnumerable();

            query = query.Where(x =>
                EqualsFilter(x.Capability, capability) &&
                EqualsFilter(x.BusinessName, business) &&
                EqualsFilter(x.Geographies, geo) &&
                EqualsFilter(x.Priorities, priority) &&
                EqualsFilter(x.FunnelStage, stage));

            if (string.Equals(timeType, "year", StringComparison.OrdinalIgnoreCase) && int.TryParse(year, out var y))
            {
                query = query.Where(x => x.CreatedOn.HasValue && x.CreatedOn.Value.Year == y);
            }
            else if (string.Equals(timeType, "range", StringComparison.OrdinalIgnoreCase))
            {
                DateTime? s = DateTime.TryParse(start, out var sv) ? sv.Date : null;
                DateTime? e = DateTime.TryParse(end, out var ev) ? ev.Date.AddDays(1).AddTicks(-1) : null;

                query = query.Where(x =>
                    x.CreatedOn.HasValue &&
                    (!s.HasValue || x.CreatedOn.Value >= s.Value) &&
                    (!e.HasValue || x.CreatedOn.Value <= e.Value));
            }

            var rows = query.ToList();

            decimal IdeaExpectedValue(BrightIdeaDumpReportViewModel r)
            {
                var expected = r.ExpectedHard + r.ExpectedSoft;
                return expected != 0m ? expected : r.PotentialSavings;
            }

            decimal IdeaRealizedValue(BrightIdeaDumpReportViewModel r)
            {
                var realized = r.RealizedHardSavings + r.RealizedSoftSavings;
                return realized != 0m ? realized : (r.ExpectedHard + r.ExpectedSoft);
            }

            var hard = rows.Sum(x => x.RealizedHardSavings);
            var soft = rows.Sum(x => x.RealizedSoftSavings);
            var realized = hard + soft;

            var pipelineHard = rows.Sum(x => x.ExpectedHard);
            var pipelineSoft = rows.Sum(x => x.ExpectedSoft);

            var weightedPipeline = PipelineForecastLogic.WeightedPipeline(rows, w);
            var forecast = realized + weightedPipeline;

            var submitted = rows.Sum(IdeaExpectedValue);

            var pendingApproval = rows
                .Where(x => IsStageLike(x, "In Approval"))
                .Sum(IdeaExpectedValue);

            var approvedImplemented = rows
                .Where(x => IsStageLike(x, "Implemented"))
                .Sum(IdeaRealizedValue);

            var approvedNotImplemented = rows
                .Where(x => IsStageLike(x, "Approved") && !IsStageLike(x, "Implemented"))
                .Sum(IdeaExpectedValue);

            var capabilityValue = rows
                .Where(x => !string.IsNullOrWhiteSpace(x.Capability))
                .GroupBy(x => x.Capability!)
                .Select(g => new
                {
                    name = g.Key,
                    hard = g.Sum(x => x.RealizedHardSavings),
                    soft = g.Sum(x => x.RealizedSoftSavings)
                })
                .OrderByDescending(x => x.hard + x.soft)
                .Take(7)
                .ToList();

            var payload = new
            {
                totalRecords = rows.Count,
                kpis = new
                {
                    hard,
                    soft,
                    weightedPipeline,
                    forecast,
                    pipelineHard,
                    pipelineSoft
                },
                stageValue = new
                {
                    submitted,
                    pendingApproval,
                    approvedImplemented,
                    approvedNotImplemented
                },
                capabilityValue
            };

            _cache.Set(responseCacheKey, payload, new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(3),
                SlidingExpiration = TimeSpan.FromMinutes(1)
            });

            return new JsonResult(payload);
        }
    }
}