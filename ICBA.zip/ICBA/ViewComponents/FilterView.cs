﻿using ICBA.Models;
using Microsoft.AspNetCore.Mvc;

namespace ICBA.ViewComponents
{
    public class FilterView : ViewComponent
    {
        public IViewComponentResult Invoke(List<BrightIdeaDumpReportViewModel> data)
        {
            if (data == null || data.Count == 0)
            {
                return View("FilterView", new FilterViewModel());
            }

            var capabilities = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var businesses = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var geographies = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var priorities = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var stages = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var years = new HashSet<int>();

            foreach (var item in data)
            {
                if (!string.IsNullOrWhiteSpace(item.Capability))
                    capabilities.Add(item.Capability.Trim());

                if (!string.IsNullOrWhiteSpace(item.BusinessName))
                    businesses.Add(item.BusinessName.Trim());

                if (!string.IsNullOrWhiteSpace(item.Geographies))
                    geographies.Add(item.Geographies.Trim());

                if (!string.IsNullOrWhiteSpace(item.Priorities))
                    priorities.Add(item.Priorities.Trim());

                if (!string.IsNullOrWhiteSpace(item.FunnelStage))
                    stages.Add(item.FunnelStage.Trim());

                if (item.CreatedOn.HasValue)
                    years.Add(item.CreatedOn.Value.Year);
            }

            var model = new FilterViewModel
            {
                Capabilities = capabilities.OrderBy(x => x).ToList(),
                Businesses = businesses.OrderBy(x => x).ToList(),
                Geographies = geographies.OrderBy(x => x).ToList(),
                Priorities = priorities.OrderBy(x => x).ToList(),
                Stages = stages.OrderBy(x => x).ToList(),
                Years = years.OrderByDescending(x => x).ToList()
            };

            return View("FilterView", model);
        }
    }
}