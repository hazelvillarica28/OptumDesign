﻿using Constants;
using Extensions;
using ICBA.Models;
using ICBA.Services;
using Microsoft.AspNetCore.Mvc;
//using ICBA.Models.ViewModel;
using Services;


namespace ICBA.ViewComponents;

[ViewComponent]
public class HeaderView : ViewComponentBase
{
    public HeaderView(DIServiceInterface serviceInterface) : base(serviceInterface)
    {
    }

    public async Task<IViewComponentResult> InvokeAsync(string title,string subtitle,DateTime asOfDate,int totalRecords,bool showExport = true)
    {
        HeaderViewModel model = new();

        model.Title = title;
        model.Subtitle = subtitle;
        model.AsOfDate = asOfDate;
        model.TotalRecords = totalRecords;
        model.ShowExport = showExport;

        return View("HeaderView", model);
    }
}
