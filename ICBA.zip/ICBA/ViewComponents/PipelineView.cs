﻿using Microsoft.AspNetCore.Mvc;

namespace ICBA.ViewComponents
{
    public class PipelineView : ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            return View("PipelineWeightConfigView");
        }
    }
}