﻿using Constants;
using ICBA.Models;
using ICBA.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Caching.Memory;
//using RCMCoding.Models.ViewModel;
using Services;
using Services.DataService;
using System.Security.Claims;
using System.Security.Principal;
namespace ICBA.ViewComponents
{
    [ViewComponent]
    public abstract class ViewComponentBase : ViewComponent
    {
        protected readonly DIServiceInterface _serviceInterface;
        public ViewComponentBase(DIServiceInterface serviceInterface)
        {
            _serviceInterface = serviceInterface;
        }

        protected Func<int, MemoryCacheEntryOptions> GetCacheOptions = seconds
      => new MemoryCacheEntryOptions().SetSlidingExpiration(TimeSpan.FromSeconds(seconds));
    }
}
