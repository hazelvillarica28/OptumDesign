﻿namespace ICBA.Constants;

public enum UserRoles
{
    UNAUTHORIZED,
    USER,
    DEV,
    ADMIN
}
