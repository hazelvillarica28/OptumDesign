﻿namespace ICBA.Constants
{
    public class ViewTags
    {
    }
}
