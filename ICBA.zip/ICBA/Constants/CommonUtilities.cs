﻿namespace ICBA.Constants
{
    public class CommonUtilities
    {
    }
}
