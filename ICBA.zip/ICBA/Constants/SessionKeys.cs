﻿namespace Constants;

public class SessionKeys
{
    public static string UserRole => "_UserRole";
}
