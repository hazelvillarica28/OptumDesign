﻿namespace ICBA.Constants
{
    public class APIUrlKeys
    {
    }
}
