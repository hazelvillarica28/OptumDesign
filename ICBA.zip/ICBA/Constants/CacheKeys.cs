﻿namespace Constants
{
    public class CacheKeys
    {
        public static string ReportBrightIdeaDumpCache => "_ReportBrightIdeaDumpCache";
    }
}
