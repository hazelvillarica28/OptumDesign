﻿namespace Constants
{
    public class SPQueryKeys
    {
        public static string SP_GetReportBrightIdeaDump => "usp_ReportBrightIdeaDump_RoleWise_new";
        public static string VW_GetReportBrightIdeaDump => "Vw_ReportBrightIdeaDump";
        
    }
}
