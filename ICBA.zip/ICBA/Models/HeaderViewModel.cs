﻿namespace ICBA.Models
{
    public class HeaderViewModel
    {
        public string Title { get; set; } = string.Empty;

        public string Subtitle { get; set; } = string.Empty;

        public DateTime AsOfDate { get; set; }

        public int TotalRecords { get; set; }

        public bool ShowExport { get; set; } = true;
    }
}
