﻿namespace ICBA.Models
{
    public class BrightIdeaDumpReportViewModel
    {

        public DateTime? CreatedOn { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public string? IdeaID { get; set; }
        public string? EmpName { get; set; }
        public string? EmployeeID { get; set; }
        public string? ManagerEmployeeID { get; set; }
        public string? ManagerName { get; set; }

        public string? GLCode { get; set; }
        public string? GLDepartmentDescription { get; set; }

        public string? IdeaTitle { get; set; }

        public string? FunctionName { get; set; }
        public string? BusinessName { get; set; }
        public string? Capability { get; set; }

        public string? IdeaProcess { get; set; }
        public string? ProblemStatement { get; set; }
        public string? Recommendation { get; set; }

        public string? AmbassadorName { get; set; }
        public string? FunctionalLeaderName { get; set; }

        public string? StageName { get; set; }
        public string? FunnelStage { get; set; }


        public decimal RealizedSavings { get; set; }

        public string? LocationName { get; set; }
        public string? Geographies { get; set; }
        public string? MasterAmbassadorName { get; set; }

        public decimal PotentialSavings { get; set; }

        public DateTime? ProposedImplDate { get; set; }

        public decimal RealizedHardSavings { get; set; }
        public decimal RealizedSoftSavings { get; set; }

        public decimal ExpectedHard { get; set; }
        public decimal ExpectedSoft { get; set; }

        public string? Stage { get; set; }
        public string? IdeaType { get; set; }
        public string? ThemeName { get; set; }
        public string? Priorities { get; set; }
        public string? IsMacroRequired { get; set; }
        public string? IsMacroBuildingHelpNeeded { get; set; }

        public string? OnshoreApprovarName { get; set; }
        public string? OffshoreApprovarName { get; set; }

        public string? IBPInitiative { get; set; }
        public string? FinanceSignOffPersonEmail { get; set; }

        public string? OGAValueLever { get; set; }
        public string? TeamType { get; set; }
        public string? ValueLeverName { get; set; }

        public string? InnovationMaturity { get; set; }
        public string? CulturalImpact { get; set; }
        public string? SubThemeName { get; set; }

        public string? MgrComments { get; set; }
        public string? BBComments { get; set; }

        public string? IdeaValidated { get; set; }
        public string? IsAI { get; set; }

        public string? BBUpdatesAndRisks { get; set; }
        public string? AIRBStatus { get; set; }

        public decimal InitialBenefitEstimateAISavings { get; set; }
        public decimal RealizedAISavingsHard { get; set; }
        public decimal RealizedAISavingsSoft { get; set; }

    }
}
