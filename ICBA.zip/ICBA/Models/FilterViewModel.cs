﻿namespace ICBA.Models
{
    public class FilterViewModel
    {
        public string? SelectedCapability { get; set; }
        public string? SelectedBusiness { get; set; }
        public string? SelectedGeography { get; set; }
        public string? SelectedPriority { get; set; }
        public string? SelectedStage { get; set; }
        public string? SelectedTime { get; set; }

        public List<string> Capabilities { get; set; } = new();
        public List<string> Businesses { get; set; } = new();
        public List<string> Geographies { get; set; } = new();
        public List<string> Priorities { get; set; } = new();
        public List<string> Stages { get; set; } = new();

        public List<int> Years { get; set; } = new();
    }
}
