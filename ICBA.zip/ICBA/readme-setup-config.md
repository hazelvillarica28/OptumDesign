﻿# JFrog Setup Guide — Using JFrog Artifactory for Private JS/CSS Dependencies

## Objective

This document explains the Optum-compliant process for managing JavaScript/CSS dependencies through **JFrog Artifactory**, replacing the legacy approach of committing client-side libraries (Bootstrap, jQuery, etc.) directly into the repository.

It covers:

- JFrog access requirements
- npm configuration using JFrog (private registry)
- Package installation and dependency management
- LibMan integration (copying files into `wwwroot/lib`)
- Repository compliance (what to commit / ignore)
- JavaScript obfuscation for production deployments


---

## 1. JFrog Access Setup

### Prerequisites

Before accessing JFrog Artifactory, each user must:

- Be a member of the security group **`AZU_ARTIFACTORY_USERS`**.
- Use their primary Microsoft account.
- Be connected to the Optum network (VPN/corporate network) as required.

> ⚠️ Without the `AZU_ARTIFACTORY_USERS` group assigned, login will fail and package repositories will not be accessible. Request access to this group before proceeding.

### JFrog Login URL

```text
https://edgecore.optum.com/ui/login
```

Authentication occurs through Optum SSO.

---

## 2. Configure JFrog for npm

After logging in:

1. Click the user profile menu (top-right).
2. Select **Set Me Up**.
3. Choose package type **NPM**.
4. Select the repository: **`glb-npm-vir`**

This is the standard virtual npm repository used for all projects — the same repository and token can be reused across every project, you do **not** need a different repository per project.

---

## 3. Generate an Access Token

Inside the **Set Me Up** screen:

1. Generate a new token.
2. Copy the **Registry URL** and the **Access Token**.

```text
Registry URL:  https://edgecore.optum.com/artifactory/api/npm/glb-npm-vir/
Access Token:  xxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

> ✅ **Important:** You only need to generate this token **once**. The same token can be stored locally and reused across all your projects — there is no need to regenerate a new token or re-authenticate `.npmrc` for every repository. Each project's `.npmrc` simply points at the same environment variable.

---

## 4. Store the Token as a Local Environment Variable

Use the Windows `setx` command to store the token once on your machine:

```powershell
setx Artifactory_JFROG_TOKEN "your-generated-jfrog-token"
```

Verify it by opening a **new** terminal/command prompt (environment variables only refresh in new sessions):

```powershell
echo $env:Artifactory_JFROG_TOKEN
```

Benefits:

- Secure, local-only storage of the credential.
- No tokens ever get committed to GitHub.
- Each developer can use their own token with the same `.npmrc` file.
- Works for **every** project on the machine — set once, use everywhere.

---

## 5. Create the `.npmrc` File

### Purpose

The `.npmrc` file tells npm:

- Which private registry to use.
- How to authenticate against it (via the environment variable, never a hardcoded token).

### Location

Create it in the **root of the solution**, alongside `package.json`:

```text
SolutionRoot/
│
├── .npmrc
├── package.json
├── libman.json
├── MyProject.sln
└── src/
```

### Configuration

```ini
registry=https://edgecore.optum.com/artifactory/api/npm/glb-npm-vir/
//edgecore.optum.com/artifactory/api/npm/glb-npm-vir/:_authToken=${Artifactory_JFROG_TOKEN}
```

> 🚫 **Do NOT** hardcode the token directly, e.g. `_authToken=eyJhbGciOi...`. Always reference the environment variable (`${Artifactory_JFROG_TOKEN}`) so the token stays local and is never pushed to source control.

Because the token lives in an environment variable on your machine, the **exact same `.npmrc` file** (with the `${Artifactory_JFROG_TOKEN}` placeholder) can be committed to every project/repo without ever exposing a secret — nothing needs to be regenerated per project.

---

## 6. `package.json` Overview

### Purpose

Tracks all npm dependencies used by the application. When packages are installed via npm, dependencies are automatically recorded here.

### Example

```json
{
  "name": "demo-origin",
  "version": "1.0.0",
  "private": true,
  "description": "JS library dependencies",
  "scripts": {
    "restore-libs": "npm install && libman restore"
  },
  "dependencies": {
    "bootstrap": "^5.3.8",
    "jquery": "^4.0.0"
  }
}
```

- `"private": true` prevents the package from accidentally being published to a public registry.
- `restore-libs` is a convenience script that installs npm packages **and** copies the required files into `wwwroot/lib` via LibMan in one step (see below).

---

## 7. Installing Libraries

Install any library through npm, exactly like a public registry — requests are transparently routed through JFrog because of the `.npmrc` configuration.

```bash
npm install bootstrap
npm install jquery
npm install datatables.net
```

If a package is unavailable through `glb-npm-vir`:

- The `npm install` will fail.
- Verify the package exists in JFrog's package search.
- Use an alternate/compatible package if it's genuinely unavailable.

---

## 8. Understanding `node_modules`

After installation, `node_modules` becomes the source of truth for every installed package:

```text
node_modules/
│
├── bootstrap/
│   └── dist/
│       ├── css/bootstrap.min.css
│       └── js/bootstrap.min.js
├── jquery/
└── datatables.net/
```

`node_modules` is **never** committed to source control — it is regenerated locally/in CI via `npm install`.

---

## 9. Using LibMan

### Why LibMan?

Legacy ASP.NET-style projects reference client libraries from `wwwroot/lib`. Instead of manually copying files out of `node_modules`, **LibMan** automates copying the specific files you need into `wwwroot/lib`.

### `libman.json`

```json
{
  "version": "3.0",
  "defaultProvider": "filesystem",
  "libraries": [
    {
      "provider": "filesystem",
      "library": "node_modules/bootstrap/dist/css",
      "destination": "wwwroot/lib/bootstrap/css",
      "files": [
        "bootstrap.min.css"
      ]
    },
    {
      "provider": "filesystem",
      "library": "node_modules/bootstrap/dist/js",
      "destination": "wwwroot/lib/bootstrap/js",
      "files": [
        "bootstrap.min.js"
      ]
    }
  ]
}
```

> ℹ️ You can add more entries the same way for any other package, e.g. jQuery:
> ```json
> {
>   "provider": "filesystem",
>   "library": "node_modules/jquery/dist",
>   "destination": "wwwroot/lib/jquery",
>   "files": [ "jquery.min.js" ]
> }
> ```

### Provider explanation

`"provider": "filesystem"` means:

- **Source** = `node_modules/...`
- **Destination** = `wwwroot/lib/...`

### Best practice

Only include the files actually used by the application. Avoid copying:

- `*.map` source maps
- documentation
- test assets / development scripts

---

## 10. Enable Automatic Library Restore on Build

Visual Studio provides a project setting:

```text
Enable Restore Client-Side Libraries on Build
```

Recommended setting: ✅ **Enabled**

Benefits:

- Automatic restore during every build.
- No manual restore step required.
- Newly added libraries are copied automatically.

---

## 11. Git Repository Compliance

### Never commit

These folders must remain local-only and be regenerated on every machine/CI run:

```text
node_modules/
wwwroot/lib/
```

### `.gitignore` example

```text
node_modules/
wwwroot/lib/
```

### What should be committed

```text
package.json
package-lock.json
.npmrc
libman.json
project files
source code
```

### What must NOT be committed

```text
node_modules/
wwwroot/lib/
tokens
credentials
```

This aligns with Optum compliance requirements — secrets and generated/vendor folders never go into source control.

---

## 12. JavaScript Obfuscation

### Purpose

JavaScript obfuscation protects client-side code by:

- Minifying files
- Renaming variables
- Making source code difficult to read
- Reducing reverse-engineering risk

### Development Mode (Debug build)

Use the readable, un-obfuscated file:

```text
site.js
```

Advantages: easy debugging, readable source, faster troubleshooting.

### Production Mode (Release/Publish build)

Generate the minified/obfuscated file:

```text
site.min.js
```

**Example**

Original:
```javascript
console.log("Hello");
```

Obfuscated:
```javascript
function _0x4a1f(){console["log"]("Hello")}
```

---

## 13. Build Configuration Logic

```text
Debug Build
    └── No Obfuscation

Release Build
    └── Generate Minified JS

Publish Build
    └── Generate Minified JS
```

### `.csproj` automation

The obfuscator — and the npm install step itself — can be wired directly into the project file so both run automatically on every build, with no manual steps:

1. Check build configuration.
2. Skip obfuscation in **Debug**.
3. Run obfuscation during **Release**/**Publish**.
4. Output to:

```text
wwwroot/js/dist/site.min.js
```

Add the following inside the `.csproj` file (as a sibling of the existing `<PropertyGroup>`/`<ItemGroup>` elements, just before the closing `</Project>` tag):

```xml
<PropertyGroup>
    <ObfuscateJavaScript Condition="'$(ObfuscateJavaScript)' == '' and '$(Configuration)' == 'Debug'">false</ObfuscateJavaScript>
    <ObfuscateJavaScript Condition="'$(ObfuscateJavaScript)' == ''">true</ObfuscateJavaScript>
</PropertyGroup>

<!-- Ensure required wwwroot folders exist before any front-end build step -->
<Target Name="EnsureFolders" BeforeTargets="BeforeBuild">
    <MakeDir Directories="$(MSBuildProjectDirectory)\wwwroot\lib" />
    <MakeDir Directories="$(MSBuildProjectDirectory)\wwwroot\js\dist" />
</Target>

<Target Name="NpmInstall" BeforeTargets="BeforeBuild" Condition="!Exists('$(MSBuildProjectDirectory)\node_modules')">
    <Message Importance="high" Text="node_modules not found — running npm install..." />
    <Exec Command="npm install" WorkingDirectory="$(MSBuildProjectDirectory)" />
</Target>

<Target Name="ObfuscateJs" AfterTargets="NpmInstall" BeforeTargets="BeforeBuild" Condition="'$(ObfuscateJavaScript)' == 'true'">
    <MakeDir Directories="$(MSBuildProjectDirectory)\wwwroot\js\dist" />
    <Exec Command="npx javascript-obfuscator wwwroot/js/site.js --output wwwroot/js/dist/site.min.js" WorkingDirectory="$(MSBuildProjectDirectory)" />
</Target>
```

What each piece does:

| Element | Purpose |
|---|---|
| `ObfuscateJavaScript` property | Defaults to `false` for a **Debug** build and `true` for every other configuration (Release/Publish), unless explicitly overridden. |
| `EnsureFolders` target | Runs before every build and creates `wwwroot/lib` and `wwwroot/js/dist` if they don't already exist, so later steps never fail on a missing folder. |
| `NpmInstall` target | Runs before every build **only if** `node_modules` is missing — so a freshly cloned repo (or a clean CI agent) automatically restores npm packages from JFrog without a manual `npm install` step. |
| `ObfuscateJs` target | Runs after `NpmInstall` and before the build, and only when `ObfuscateJavaScript` is `true`. It obfuscates/minifies `wwwroot/js/site.js` into `wwwroot/js/dist/site.min.js` using `npx javascript-obfuscator`. |

> ℹ️ Because `NpmInstall` only triggers when `node_modules` is absent, it won't slow down every single build — it only kicks in the first time (or after a clean/pull), while `EnsureFolders` and the Debug/Release check keep obfuscation from running unnecessarily during local development.

> ✅ **Recommended:** add `javascript-obfuscator` as a `devDependency` in `package.json` (`npm install --save-dev javascript-obfuscator`). This pins a specific version and lets `npx` resolve it through JFrog (`glb-npm-vir`) together with the rest of your dependencies, instead of reaching out to the public npm registry at build time.

### Deployment behavior

| Environment | File used |
|---|---|
| Local development | `site.js` |
| Stack Cloud / Cloud deployment | `site.min.js` |

Reason: a cloud deployment is treated as a Release build, so obfuscation must run automatically as part of that build.

---

## Key Takeaways

1. JFrog Artifactory (`glb-npm-vir`) is now the approved source for JavaScript dependencies.
2. npm packages must be pulled through the Optum JFrog registry via `.npmrc`.
3. Authentication must use a locally stored token (`Artifactory_JFROG_TOKEN`), never a hardcoded value.
4. **One token can be generated once and reused across every project** — there's no need to regenerate it or re-authenticate `.npmrc` per repository.
5. `package.json` becomes the authoritative dependency manifest.
6. `node_modules` and `wwwroot/lib` must never be committed to GitHub.
7. LibMan copies the required files from `node_modules` into `wwwroot/lib` based on `libman.json`.
8. JavaScript obfuscation should run automatically during Release/Publish builds.
9. The team must follow this workflow to remain compliant with Optum security and dependency management standards.

---


 


